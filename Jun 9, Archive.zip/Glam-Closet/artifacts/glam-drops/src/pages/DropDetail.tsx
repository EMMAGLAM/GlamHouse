import React, { useState, useRef } from 'react';
import { useRoute } from 'wouter';
import { useGetDrop, useAddToCart, useGetWishlist, useAddToWishlist, useRemoveFromWishlist, getGetWishlistQueryKey } from '@workspace/api-client-react';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { CountdownTimer } from '@/components/CountdownTimer';
import { ShippingReturns } from '@/components/ShippingReturns';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { Heart } from 'lucide-react';

export default function DropDetail() {
  const [, params] = useRoute('/drops/:id');
  const dropId = params?.id ? parseInt(params.id) : 0;
  
  const { data: drop, isLoading } = useGetDrop(dropId);
  
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [selectedColor, setSelectedColor] = useState<string>('');
  const [activeImg, setActiveImg] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const { data: wishlistData } = useGetWishlist();
  const addToWishlist = useAddToWishlist();
  const removeFromWishlist = useRemoveFromWishlist();
  const addToCart = useAddToCart();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const isWishlisted = drop ? wishlistData?.some(item => item.dropId === drop.id) : false;

  React.useEffect(() => {
    if (drop) {
      if (drop.sizes?.length && !selectedSize) setSelectedSize(drop.sizes[0]);
      if (drop.colors?.length && !selectedColor) setSelectedColor(drop.colors[0]);
    }
  }, [drop]);

  React.useEffect(() => {
    setActiveImg(0);
    const el = scrollRef.current;
    const first = el?.children[0] as HTMLElement | undefined;
    if (el && first) {
      const delta = first.getBoundingClientRect().left - el.getBoundingClientRect().left;
      el.scrollTo({ left: el.scrollLeft + delta });
    }
  }, [drop?.id]);

  if (isLoading) {
    return (
      <Layout>
        <div className="pt-28 container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <Skeleton className="w-full aspect-[3/4] bg-muted/50 rounded-2xl" />
            <div className="space-y-8 pt-12">
              <Skeleton className="h-12 w-3/4 bg-muted/50" />
              <Skeleton className="h-8 w-1/4 bg-muted/50" />
              <Skeleton className="h-32 w-full bg-muted/50" />
              <Skeleton className="h-16 w-full bg-muted/50" />
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (!drop) {
    return (
      <Layout>
        <div className="pt-28 container mx-auto px-4 py-32 text-center">
          <h1 className="font-serif text-4xl mb-4">Piece Not Found</h1>
          <p className="text-muted-foreground">The item you are looking for does not exist.</p>
        </div>
      </Layout>
    );
  }

  const handleWishlistToggle = () => {
    if (isWishlisted) {
      removeFromWishlist.mutate(
        { dropId: drop.id },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
            toast({ title: 'Removed from wishlist' });
          }
        }
      );
    } else {
      addToWishlist.mutate(
        { dropId: drop.id },
        {
          onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
            toast({ title: 'Added to wishlist' });
          }
        }
      );
    }
  };

  const handleAddToCart = () => {
    if (!selectedSize && drop.sizes?.length) {
      toast({ title: 'Please select a size', variant: 'destructive' });
      return;
    }
    if (!selectedColor && drop.colors?.length) {
      toast({ title: 'Please select a color', variant: 'destructive' });
      return;
    }

    addToCart.mutate(
      { 
        data: { 
          dropId: drop.id, 
          quantity: 1,
          size: selectedSize || 'OS',
          color: selectedColor || 'Default'
        } 
      },
      {
        onSuccess: () => {
          toast({ title: 'Added to cart', description: `${drop.name} has been added to your cart.` });
        }
      }
    );
  };

  const collectedImages = Array.from(
    new Set([drop.imageUrl, ...(drop.imageUrls ?? [])].filter(Boolean) as string[]),
  );
  const images = collectedImages.length ? collectedImages : ['/images/drop-dress.png'];

  const handleGalleryScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const containerCenter = el.getBoundingClientRect().left + el.clientWidth / 2;
    let best = 0;
    let bestDist = Infinity;
    Array.from(el.children).forEach((child, i) => {
      const r = (child as HTMLElement).getBoundingClientRect();
      const dist = Math.abs(r.left + r.width / 2 - containerCenter);
      if (dist < bestDist) {
        bestDist = dist;
        best = i;
      }
    });
    setActiveImg(best);
  };

  const scrollToImage = (idx: number) => {
    const el = scrollRef.current;
    const child = el?.children[idx] as HTMLElement | undefined;
    if (!el || !child) return;
    const delta = child.getBoundingClientRect().left - el.getBoundingClientRect().left;
    el.scrollTo({ left: el.scrollLeft + delta, behavior: 'smooth' });
  };

  return (
    <Layout>
      <div className="pt-28">
        <div className="container mx-auto px-4 py-12 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20">
            
            {/* Images - Left Column */}
            <div className="space-y-4">
              <div
                ref={scrollRef}
                onScroll={handleGalleryScroll}
                className="flex aspect-[3/4] w-full bg-muted overflow-x-auto snap-x snap-mandatory rounded-2xl [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
              >
                {images.map((url, idx) => (
                  <div key={idx} className="snap-center shrink-0 w-full h-full">
                    <img
                      src={url}
                      alt={`${drop.name} ${idx + 1}`}
                      onError={(e) => {
                        const img = e.currentTarget;
                        if (!img.src.endsWith('/images/drop-dress.png')) {
                          img.src = '/images/drop-dress.png';
                        }
                      }}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>

              {images.length > 1 && (
                <div className="flex justify-center gap-2">
                  {images.map((_, idx) => (
                    <button
                      key={idx}
                      type="button"
                      aria-label={`صورة ${idx + 1}`}
                      onClick={() => scrollToImage(idx)}
                      className={`h-1.5 rounded-full transition-all ${activeImg === idx ? 'w-6 bg-foreground' : 'w-1.5 bg-foreground/30'}`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Details - Right Column */}
            <div className="flex flex-col lg:pl-8">
              <div className="mb-10">
                <p className="text-xs text-muted-foreground uppercase tracking-widest mb-4">{drop.brand}</p>
                <h1 className="font-serif text-2xl lg:text-3xl text-foreground mb-4 leading-tight">{drop.name}</h1>
                <div className="flex flex-wrap items-baseline gap-4 mb-8">
                  <span className="font-serif text-2xl text-foreground">{drop.price.toLocaleString('en-US')} ر.س</span>
                  {drop.originalPrice && (
                    <span className="text-muted-foreground line-through text-sm">{drop.originalPrice.toLocaleString('en-US')} ر.س</span>
                  )}
                </div>
                <p className="text-foreground/80 leading-relaxed font-light text-sm">
                  {drop.description}
                </p>
              </div>

              {drop.status === 'upcoming' && drop.dropDate && (
                <div className="py-6 border-y border-border mb-10">
                  <p className="uppercase tracking-widest text-xs text-muted-foreground mb-4">Releasing In</p>
                  <CountdownTimer targetDate={drop.dropDate} className="text-xl" />
                </div>
              )}

              <div className="space-y-8 mb-12">
                {/* Size Selector */}
                {drop.sizes && drop.sizes.length > 0 && (
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <span className="text-xs uppercase tracking-widest text-muted-foreground">Size</span>
                      <button className="text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground">Size Guide</button>
                    </div>
                    <div className="flex flex-wrap gap-3">
                      {drop.sizes.map((size) => (
                        <button 
                          key={size}
                          onClick={() => setSelectedSize(size)}
                          className={`w-12 h-12 flex items-center justify-center border text-xs uppercase tracking-widest transition-colors ${
                            selectedSize === size 
                              ? 'border-primary bg-primary text-primary-foreground' 
                              : 'border-border text-foreground hover:border-foreground'
                          }`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Color Selector */}
                {drop.colors && drop.colors.length > 0 && (
                  <div>
                    <span className="text-xs uppercase tracking-widest text-muted-foreground mb-4 block">Color: {selectedColor}</span>
                    <div className="flex flex-wrap gap-3">
                      {drop.colors.map((color) => (
                        <button 
                          key={color}
                          onClick={() => setSelectedColor(color)}
                          className={`px-6 h-12 flex items-center justify-center border text-xs uppercase tracking-widest transition-colors ${
                            selectedColor === color 
                              ? 'border-primary text-primary' 
                              : 'border-border text-foreground hover:border-foreground'
                          }`}
                        >
                          {color}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="flex flex-col gap-4 mb-16">
                <Button 
                  size="lg" 
                  className="w-full rounded-none bg-foreground text-background hover:bg-foreground/90 uppercase tracking-widest text-xs h-14"
                  onClick={handleAddToCart}
                  disabled={drop.status !== 'live' || drop.stock === 0}
                >
                  {drop.status === 'live' ? (drop.stock > 0 ? 'Add to Bag' : 'Sold Out') : 'Coming Soon'}
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="w-full rounded-none border-border hover:bg-muted uppercase tracking-widest text-xs h-14"
                  onClick={handleWishlistToggle}
                >
                  {isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
                  <Heart className={`w-4 h-4 ml-3 ${isWishlisted ? 'fill-foreground text-foreground' : ''}`} />
                </Button>
              </div>

              <ShippingReturns />

            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
