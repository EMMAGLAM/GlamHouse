import React, { useState } from 'react';
import { useLocation, useSearch } from 'wouter';
import { useListDrops, useListCategories, ListDropsStatus } from '@workspace/api-client-react';
import { Layout } from '@/components/layout/Layout';
import { DropCard } from '@/components/DropCard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useLang } from '@/lib/i18n';

export default function Catalog() {
  const { t } = useLang();
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const initialCategory = searchParams.get('category') || undefined;
  const initialStatus = (searchParams.get('status') as ListDropsStatus) || undefined;

  const [category, setCategory] = useState<string | undefined>(initialCategory);
  const [status, setStatus] = useState<ListDropsStatus | undefined>(initialStatus);

  const { data: drops, isLoading: isLoadingDrops } = useListDrops({ category, status });
  const { data: categories } = useListCategories();

  const [, setLocation] = useLocation();
  const updateUrl = (newCategory: string | undefined, newStatus: ListDropsStatus | undefined) => {
    const params = new URLSearchParams();
    if (newCategory) params.set('category', newCategory);
    if (newStatus) params.set('status', newStatus);
    const newSearch = params.toString();
    setLocation(`/drops${newSearch ? `?${newSearch}` : ''}`);
  };

  const handleCategoryChange = (val: string) => {
    const newVal = val === 'all' ? undefined : val;
    setCategory(newVal);
    updateUrl(newVal, status);
  };

  const handleStatusChange = (val: string) => {
    const newVal = val === 'all' ? undefined : val as ListDropsStatus;
    setStatus(newVal);
    updateUrl(category, newVal);
  };

  return (
    <Layout>
      <div className="pt-28">
        <div className="container mx-auto px-4 py-12 md:py-16 text-center">
          <h1 className="font-serif text-4xl md:text-5xl text-foreground font-bold mb-4">{t('theWardrobeCatalog')}</h1>
          <p className="text-muted-foreground max-w-xl mx-auto text-sm">
            {t('exploreCurated')}
          </p>
        </div>

        <div className="container mx-auto px-4 mb-24">
          <div className="flex flex-col gap-8 mb-12">

            {/* Category Tabs */}
            <div className="flex overflow-x-auto hide-scrollbar border-b border-border">
              <button
                onClick={() => handleCategoryChange('all')}
                className={`whitespace-nowrap px-6 py-4 text-xs uppercase tracking-widest transition-colors border-b-2 font-medium ${
                  !category ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('allPieces')}
              </button>
              {categories?.map((c) => (
                <button
                  key={c.id}
                  onClick={() => handleCategoryChange(c.slug)}
                  className={`whitespace-nowrap px-6 py-4 text-xs uppercase tracking-widest transition-colors border-b-2 font-medium ${
                    category === c.slug ? 'border-primary text-primary' : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {c.name}
                </button>
              ))}
            </div>

            {/* Status Filter */}
            <div className="flex flex-wrap gap-4 items-center">
              <span className="text-xs uppercase tracking-widest text-muted-foreground">{t('status')}:</span>
              <div className="flex gap-2">
                {[
                  { label: t('allStatus'), value: 'all' },
                  { label: t('liveStatus'), value: 'live' },
                  { label: t('upcomingStatus'), value: 'upcoming' },
                  { label: t('soldOut'), value: 'sold_out' },
                ].map((s) => (
                  <button
                    key={s.value}
                    onClick={() => handleStatusChange(s.value)}
                    className={`px-4 py-2 text-xs uppercase tracking-widest border transition-colors ${
                      (status || 'all') === s.value
                        ? 'border-primary bg-primary/5 text-primary'
                        : 'border-transparent text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Drops Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-8 gap-y-12">
            {isLoadingDrops ? (
              Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="flex flex-col gap-4">
                  <Skeleton className="w-full aspect-[3/4] bg-muted/50 rounded-2xl" />
                  <Skeleton className="h-6 w-3/4 bg-muted/50" />
                  <Skeleton className="h-4 w-1/2 bg-muted/50" />
                </div>
              ))
            ) : drops?.length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-32 text-center border border-border bg-card">
                <h3 className="font-serif text-2xl text-foreground mb-4">{t('noItemsFound')}</h3>
                <p className="text-muted-foreground mb-8 text-sm">{t('adjustFilters')}</p>
                <Button
                  variant="outline"
                  className="rounded-none border-primary text-primary hover:bg-primary hover:text-primary-foreground uppercase tracking-widest text-xs"
                  onClick={() => { setCategory(undefined); setStatus(undefined); updateUrl(undefined, undefined); }}
                >
                  {t('clearFilters')}
                </Button>
              </div>
            ) : (
              drops?.map((drop) => (
                <DropCard key={drop.id} drop={drop} />
              ))
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
