import React, { useState } from 'react';
import { useGetCart, useRemoveCartItem, useUpdateCartItem, getGetCartQueryKey } from '@workspace/api-client-react';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, Lock, ExternalLink } from 'lucide-react';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { Separator } from '@/components/ui/separator';
import { ShippingReturns } from '@/components/ShippingReturns';
import { useLang } from '@/lib/i18n';

const BASE = import.meta.env.BASE_URL.replace(/\/$/, '');

export default function Cart() {
  const { t } = useLang();
  const { data: cart, isLoading } = useGetCart();
  const removeCartItem = useRemoveCartItem();
  const updateCartItem = useUpdateCartItem();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [checkingOut, setCheckingOut] = useState(false);

  const handleRemove = (itemId: number) => {
    removeCartItem.mutate(
      { itemId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() });
          toast({ title: t('remove') });
        },
      }
    );
  };

  const handleUpdateQuantity = (itemId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    updateCartItem.mutate(
      { itemId, data: { quantity: newQuantity } },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetCartQueryKey() }) }
    );
  };

  const handleShopifyCheckout = async () => {
    if (!cart?.items?.length) return;
    setCheckingOut(true);
    try {
      // Check Shopify status first
      const statusRes = await fetch(`${BASE}/api/shopify/status`);
      const status = await statusRes.json();

      if (!status.connected) {
        toast({
          title: 'Shopify غير متصل بعد',
          description: 'يرجى ربط متجر Shopify أولاً من لوحة التحكم.',
          variant: 'destructive',
        });
        setCheckingOut(false);
        return;
      }

      // Build items list — use product name as fallback variantId hint
      // Once Shopify catalog is synced, real variant IDs will be used
      const items = cart.items.map((item) => ({
        variantId: item.drop.shopifyVariantId ?? null,
        quantity: item.quantity,
        name: item.drop.name,
      }));

      const hasVariantIds = items.every((i) => i.variantId);

      if (!hasVariantIds) {
        // Shopify catalog not yet synced — show clear message
        toast({
          title: 'الكتالوج لم يُزامن بعد مع Shopify',
          description: 'قريباً — بعد مزامنة المنتجات مع Shopify يُفتح الـ checkout تلقائياً.',
        });
        setCheckingOut(false);
        return;
      }

      const res = await fetch(`${BASE}/api/shopify/checkout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items }),
      });
      const data = await res.json();

      if (!res.ok || data.error) {
        toast({ title: 'خطأ', description: data.error, variant: 'destructive' });
        setCheckingOut(false);
        return;
      }

      // Redirect to Shopify hosted checkout
      window.location.href = data.checkoutUrl;
    } catch (e: any) {
      toast({ title: 'خطأ', description: e.message, variant: 'destructive' });
      setCheckingOut(false);
    }
  };

  return (
    <Layout>
      <div className="bg-card border-b border-border py-12 md:py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="font-serif text-4xl md:text-5xl text-foreground font-light mb-4">{t('yourCart')}</h1>
          <p className="text-muted-foreground max-w-xl mx-auto text-sm uppercase tracking-widest">
            {cart?.itemCount || 0} {t('allPieces').toLowerCase()}
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 md:py-24">
        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-6">
              {[1, 2].map((i) => <Skeleton key={i} className="h-40 w-full bg-muted/50 rounded-none" />)}
            </div>
            <Skeleton className="h-80 w-full bg-muted/50 rounded-none" />
          </div>
        ) : cart && cart.items.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-20">

            {/* Cart Items */}
            <div className="lg:col-span-2">
              <div className="hidden md:grid grid-cols-12 gap-4 pb-4 border-b border-border text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
                <div className="col-span-6">{t('allPieces')}</div>
                <div className="col-span-2 text-center">Qty</div>
                <div className="col-span-2 text-right">{t('price')}</div>
                <div className="col-span-2 text-right">Total</div>
              </div>

              <div className="divide-y divide-border">
                {cart.items.map((item) => (
                  <div key={item.id} className="py-8 grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-4 items-center">
                    <div className="col-span-1 md:col-span-6 flex gap-6">
                      <Link href={`/drops/${item.dropId}`} className="shrink-0">
                        <div className="w-24 h-32 bg-muted border border-border rounded-xl overflow-hidden">
                          <img src={item.drop.imageUrl} alt={item.drop.name} className="w-full h-full object-cover" />
                        </div>
                      </Link>
                      <div className="flex flex-col justify-center">
                        <p className="text-[10px] text-primary uppercase tracking-[0.2em] mb-2">{item.drop.brand}</p>
                        <Link href={`/drops/${item.dropId}`} className="font-serif text-lg text-foreground hover:text-primary transition-colors mb-2">
                          {item.drop.name}
                        </Link>
                        {item.size && <p className="text-sm text-muted-foreground mb-0.5">{t('size')}: {item.size}</p>}
                        {item.color && <p className="text-sm text-muted-foreground mb-4">{t('color')}: {item.color}</p>}
                        <button
                          onClick={() => handleRemove(item.id)}
                          className="text-[10px] text-muted-foreground hover:text-destructive flex items-center gap-1 uppercase tracking-[0.15em] w-fit"
                        >
                          <Trash2 className="w-3 h-3" /> {t('remove')}
                        </button>
                      </div>
                    </div>

                    <div className="col-span-1 md:col-span-2 flex items-center md:justify-center">
                      <div className="flex items-center border border-border bg-card">
                        <button
                          className="w-8 h-10 flex items-center justify-center text-foreground hover:text-primary transition-colors disabled:opacity-50"
                          onClick={() => handleUpdateQuantity(item.id, item.quantity - 1)}
                          disabled={item.quantity <= 1}
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="w-10 text-center font-mono text-sm">{item.quantity}</span>
                        <button
                          className="w-8 h-10 flex items-center justify-center text-foreground hover:text-primary transition-colors disabled:opacity-50"
                          onClick={() => handleUpdateQuantity(item.id, item.quantity + 1)}
                          disabled={item.quantity >= item.drop.stock}
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    <div className="hidden md:block col-span-2 text-right">
                      <span className="font-mono text-muted-foreground">{item.drop.price.toLocaleString('en-US')} ر.س</span>
                    </div>
                    <div className="col-span-1 md:col-span-2 flex justify-between md:justify-end items-center">
                      <span className="md:hidden text-[10px] uppercase tracking-widest text-muted-foreground">Total:</span>
                      <span className="font-mono text-lg text-foreground">{(item.drop.price * item.quantity).toLocaleString('en-US')} ر.س</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="bg-card border border-border p-8 sticky top-32">
                <h2 className="font-serif text-2xl text-foreground font-light mb-8">{t('total')}</h2>

                <div className="space-y-4 mb-8 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t('total')} ({cart.itemCount})</span>
                    <span className="font-mono text-foreground">{cart.total.toLocaleString('en-US')} ر.س</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">{t('freeShipping')}</span>
                    <span className="text-foreground uppercase tracking-widest text-[10px]">Complimentary</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Taxes</span>
                    <span className="text-muted-foreground italic text-xs">At checkout</span>
                  </div>
                </div>

                <Separator className="bg-border mb-6" />

                <div className="flex justify-between items-end mb-8">
                  <span className="font-sans text-[10px] uppercase tracking-[0.2em] text-foreground">{t('total')}</span>
                  <span className="font-mono text-3xl text-foreground">{cart.total.toLocaleString('en-US')} ر.س</span>
                </div>

                {/* Shopify Checkout Button */}
                <Button
                  size="lg"
                  className="w-full rounded-none bg-foreground text-background hover:bg-foreground/80 uppercase tracking-[0.2em] text-[10px] h-14 mb-4 flex items-center gap-2"
                  onClick={handleShopifyCheckout}
                  disabled={checkingOut}
                >
                  {checkingOut ? (
                    <span className="flex items-center gap-2">
                      <span className="w-3 h-3 border border-background/50 border-t-background rounded-full animate-spin" />
                      جاري الانتقال...
                    </span>
                  ) : (
                    <>
                      <ExternalLink className="w-3.5 h-3.5" />
                      {t('checkout')} — Shopify
                    </>
                  )}
                </Button>

                <div className="flex items-center justify-center gap-2 text-muted-foreground text-[10px] uppercase tracking-[0.15em]">
                  <Lock className="w-3 h-3" /> Secure Shopify Checkout
                </div>

                {/* Shopify badge */}
                <div className="mt-6 pt-5 border-t border-border/50 text-center">
                  <p className="font-sans text-[9px] uppercase tracking-[0.2em] text-muted-foreground/60">
                    Powered by Shopify
                  </p>
                </div>

                <div className="mt-6">
                  <ShippingReturns />
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center max-w-lg mx-auto">
            <div className="w-20 h-20 border border-border flex items-center justify-center mb-8">
              <ShoppingBag className="w-7 h-7 text-muted-foreground" />
            </div>
            <h2 className="font-serif text-3xl text-foreground font-light mb-4">{t('cartEmpty')}</h2>
            <p className="text-muted-foreground mb-10 leading-relaxed text-sm">{t('cartEmptyDesc')}</p>
            <Link href="/drops">
              <Button size="lg" className="rounded-none bg-foreground text-background hover:bg-foreground/80 uppercase tracking-[0.2em] text-[10px] h-13 px-10">
                {t('shopNow')} <ArrowRight className="w-3.5 h-3.5 ml-2" />
              </Button>
            </Link>
          </div>
        )}
      </div>
    </Layout>
  );
}
