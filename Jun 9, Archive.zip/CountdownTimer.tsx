import React, { useState, useEffect } from 'react';

interface CountdownTimerProps {
  targetDate: string | null | undefined;
  className?: string;
}

export function CountdownTimer({ targetDate, className = '' }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<{ days: number; hours: number; minutes: number; seconds: number } | null>(null);

  useEffect(() => {
    if (!targetDate) return;

    const calculateTimeLeft = () => {
      const difference = new Date(targetDate).getTime() - new Date().getTime();
      
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        });
      } else {
        setTimeLeft(null);
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [targetDate]);

  if (!targetDate || !timeLeft) {
    return null;
  }

  const formatNumber = (num: number) => num.toString().padStart(2, '0');

  return (
    <div className={`flex items-center gap-2 text-primary font-mono text-sm tracking-widest ${className}`}>
      <div className="flex flex-col items-center">
        <span className="font-bold">{formatNumber(timeLeft.days)}</span>
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Days</span>
      </div>
      <span className="text-muted-foreground pb-4">:</span>
      <div className="flex flex-col items-center">
        <span className="font-bold">{formatNumber(timeLeft.hours)}</span>
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Hrs</span>
      </div>
      <span className="text-muted-foreground pb-4">:</span>
      <div className="flex flex-col items-center">
        <span className="font-bold">{formatNumber(timeLeft.minutes)}</span>
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Min</span>
      </div>
      <span className="text-muted-foreground pb-4">:</span>
      <div className="flex flex-col items-center">
        <span className="font-bold">{formatNumber(timeLeft.seconds)}</span>
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Sec</span>
      </div>
    </div>
  );
}
