import { Router } from "express";
import { db } from "@workspace/db";
import { cartItemsTable, dropsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

const SESSION_ID = "guest-session";

function formatDrop(drop: typeof dropsTable.$inferSelect) {
  return {
    id: drop.id,
    name: drop.name,
    description: drop.description,
    price: parseFloat(drop.price),
    originalPrice: drop.originalPrice ? parseFloat(drop.originalPrice) : null,
    imageUrl: drop.imageUrl,
    imageUrls: drop.imageUrls ?? [],
    category: drop.category,
    brand: drop.brand,
    sizes: drop.sizes ?? [],
    colors: drop.colors ?? [],
    stock: drop.stock,
    status: drop.status,
    featured: drop.featured,
    dropDate: drop.dropDate ? drop.dropDate.toISOString() : null,
    endDate: drop.endDate ? drop.endDate.toISOString() : null,
    tags: drop.tags ?? [],
    shopifyProductId: drop.shopifyProductId ?? null,
    shopifyVariantId: drop.shopifyVariantId ?? null,
  };
}

router.get("/cart", async (req, res) => {
  const items = await db.select().from(cartItemsTable).where(eq(cartItemsTable.sessionId, SESSION_ID));
  const dropIds = items.map((i) => i.dropId);

  let drops: (typeof dropsTable.$inferSelect)[] = [];
  if (dropIds.length > 0) {
    drops = await db.select().from(dropsTable);
    drops = drops.filter((d) => dropIds.includes(d.id));
  }

  const dropMap = new Map(drops.map((d) => [d.id, d]));
  const enrichedItems = items.map((item) => {
    const drop = dropMap.get(item.dropId)!;
    return {
      id: item.id,
      dropId: item.dropId,
      quantity: item.quantity,
      size: item.size,
      color: item.color,
      drop: formatDrop(drop),
    };
  });

  const total = enrichedItems.reduce((sum, item) => {
    return sum + (item.drop.price * item.quantity);
  }, 0);

  const itemCount = enrichedItems.reduce((sum, item) => sum + item.quantity, 0);

  res.json({ items: enrichedItems, total, itemCount });
});

router.post("/cart", async (req, res) => {
  const { dropId, quantity, size, color } = req.body;

  if (!dropId || !quantity || !size || !color) {
    return res.status(400).json({ error: "Missing required fields" });
  }

  const [drop] = await db.select().from(dropsTable).where(eq(dropsTable.id, dropId));
  if (!drop) {
    return res.status(404).json({ error: "Drop not found" });
  }

  const [existing] = await db
    .select()
    .from(cartItemsTable)
    .where(
      and(
        eq(cartItemsTable.sessionId, SESSION_ID),
        eq(cartItemsTable.dropId, dropId),
        eq(cartItemsTable.size, size),
        eq(cartItemsTable.color, color),
      ),
    );

  if (existing) {
    const [updated] = await db
      .update(cartItemsTable)
      .set({ quantity: existing.quantity + quantity })
      .where(eq(cartItemsTable.id, existing.id))
      .returning();
    return res.status(201).json({ ...updated, drop: formatDrop(drop) });
  }

  const [item] = await db
    .insert(cartItemsTable)
    .values({ sessionId: SESSION_ID, dropId, quantity, size, color })
    .returning();

  return res.status(201).json({ ...item, drop: formatDrop(drop) });
});

router.patch("/cart/:itemId", async (req, res) => {
  const itemId = parseInt(req.params.itemId);
  const { quantity } = req.body;

  if (isNaN(itemId)) return res.status(400).json({ error: "Invalid itemId" });
  if (!quantity || quantity < 1) return res.status(400).json({ error: "Invalid quantity" });

  const [item] = await db
    .update(cartItemsTable)
    .set({ quantity })
    .where(and(eq(cartItemsTable.id, itemId), eq(cartItemsTable.sessionId, SESSION_ID)))
    .returning();

  if (!item) return res.status(404).json({ error: "Cart item not found" });

  const [drop] = await db.select().from(dropsTable).where(eq(dropsTable.id, item.dropId));
  return res.json({ ...item, drop: formatDrop(drop) });
});

router.delete("/cart/:itemId", async (req, res) => {
  const itemId = parseInt(req.params.itemId);
  if (isNaN(itemId)) return res.status(400).json({ error: "Invalid itemId" });

  await db
    .delete(cartItemsTable)
    .where(and(eq(cartItemsTable.id, itemId), eq(cartItemsTable.sessionId, SESSION_ID)));

  return res.status(204).send();
});

export default router;
