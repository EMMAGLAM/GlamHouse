import type { TranslationKey } from './i18n';

export interface CategoryDef {
  slug: string;
  arKey: TranslationKey;
  en: string;
}

export interface DepartmentDef {
  id: 'women' | 'men';
  labelKey: TranslationKey;
  categories: CategoryDef[];
}

export const womenCategories: CategoryDef[] = [
  { slug: 'evening-dresses', arKey: 'eveningDresses', en: 'Evening Dresses' },
  { slug: 'cocktail-dresses', arKey: 'cocktailDresses', en: 'Cocktail Dresses' },
  { slug: 'casual-dresses', arKey: 'casualDresses', en: 'Casual Dresses' },
  { slug: 'beach', arKey: 'beachPicks', en: 'Beach Selection' },
  { slug: 'tops', arKey: 'tops', en: 'Tops' },
  { slug: 'suits', arKey: 'suits', en: 'Suits' },
  { slug: 'sets', arKey: 'sets', en: 'Sets' },
  { slug: 'activewear', arKey: 'activewear', en: 'Active Wear' },
  { slug: 'accessories', arKey: 'accessories', en: 'Accessories' },
];

export const menCategories: CategoryDef[] = [
  { slug: 'men-activewear', arKey: 'menActivewear', en: 'Men Activewear' },
  { slug: 'men-casual-wear', arKey: 'menCasual', en: 'Men Casual Wear' },
  { slug: 'men-summer-collection', arKey: 'menSummer', en: 'Men Summer Collection' },
  { slug: 'men-accessories', arKey: 'menAccessories', en: 'Men Accessories' },
];

export const departments: DepartmentDef[] = [
  { id: 'women', labelKey: 'women', categories: womenCategories },
  { id: 'men', labelKey: 'men', categories: menCategories },
];
