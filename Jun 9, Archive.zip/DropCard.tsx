import React from 'react';
import { Link } from 'wouter';
import { Heart } from 'lucide-react';
import { Drop, useAddToWishlist, useRemoveFromWishlist, useGetWishlist, getGetWishlistQueryKey } from '@workspace/api-client-react';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { useLang } from '@/lib/i18n';

interface DropCardProps {
  drop: Drop;
}

export function DropCard({ drop }: DropCardProps) {
  const { t } = useLang();
  const { data: wishlistData } = useGetWishlist();
  const addToWishlist = useAddToWishlist();
  const removeFromWishlist = useRemoveFromWishlist();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const isWishlisted = wishlistData?.some((item) => item.dropId === drop.id) ?? false;

  const handleWishlistToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isWishlisted) {
      removeFromWishlist.mutate(
        { dropId: drop.id },
        { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() }); toast({ title: t('removedFromWishlist') }); } }
      );
    } else {
      addToWishlist.mutate(
        { dropId: drop.id },
        { onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() }); toast({ title: t('addedToWishlist') }); } }
      );
    }
  };

  const statusLabel =
    drop.status === 'live' ? 'Live' :
    drop.status === 'upcoming' ? 'Coming Soon' :
    'Sold Out';

  return (
    <Link href={`/drops/${drop.id}`} className="group flex flex-col">
      {/* image */}
      <div className="relative aspect-[3/4] overflow-hidden bg-muted mb-4 rounded-2xl">
        <img
          src={drop.imageUrl || '/images/drop-dress.png'}
          alt={drop.name}
          onError={(e) => {
            const img = e.currentTarget;
            if (!img.src.endsWith('/images/drop-dress.png')) {
              img.src = '/images/drop-dress.png';
            }
          }}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />

        {/* status pill */}
        <span className={`absolute top-3 left-3 font-sans text-[9px] uppercase tracking-[0.2em] px-2.5 py-1 ${
          drop.status === 'live'
            ? 'bg-background/90 text-foreground'
            : drop.status === 'upcoming'
            ? 'bg-primary/90 text-primary-foreground'
            : 'bg-foreground/60 text-background'
        }`}>
          {statusLabel}
        </span>

        {/* wishlist */}
        <button
          onClick={handleWishlistToggle}
          className="absolute top-3 right-3 z-10 w-8 h-8 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 backdrop-blur-sm"
          aria-label="Toggle wishlist"
        >
          <Heart className={`w-3.5 h-3.5 transition-all ${isWishlisted ? 'fill-primary text-primary' : 'text-foreground stroke-[1.5]'}`} />
        </button>
      </div>

      {/* meta */}
      <div className="flex flex-col gap-1">
        <p className="font-sans text-[9px] uppercase tracking-[0.25em] text-muted-foreground">{drop.brand}</p>
        <h3 className="font-serif font-light text-foreground text-lg leading-tight line-clamp-1 group-hover:text-primary transition-colors">
          {drop.name}
        </h3>
        <div className="flex items-baseline gap-2 mt-0.5">
          <span className="font-sans text-sm text-foreground">{drop.price.toLocaleString('en-US')} ر.س</span>
          {drop.originalPrice && (
            <span className="font-sans text-xs text-muted-foreground line-through">{drop.originalPrice.toLocaleString('en-US')} ر.س</span>
          )}
        </div>
      </div>
    </Link>
  );
}
