import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Layout } from '@/components/layout/Layout';
import { Button } from '@/components/ui/button';
import { Plus, Pencil, Trash2, X, ChevronUp, ChevronDown, Star, Package, TrendingUp, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const ADMIN_TOKEN = 'emma-glam-admin-2024';
const BASE = import.meta.env.BASE_URL.replace(/\/$/, '');

const categories = [
  { value: 'evening-dresses', label: 'فساتين السهرة' },
  { value: 'cocktail-dresses', label: 'فساتين الكوكتيل' },
  { value: 'casual-dresses', label: 'فساتين كاجوال' },
  { value: 'beach', label: 'مختارات البحر' },
  { value: 'tops', label: 'التوبس' },
  { value: 'suits', label: 'البدلات' },
  { value: 'sets', label: 'أطقم' },
  { value: 'activewear', label: 'الملابس الرياضية' },
];

const emptyForm = {
  name: '', description: '', price: '', originalPrice: '',
  imageUrl: '', category: 'evening-dresses', brand: 'EMMA GLAM',
  sizes: 'XS, S, M, L, XL', colors: '', stock: '10',
  status: 'live' as 'live' | 'upcoming' | 'sold_out', featured: false,
  dropDate: '', endDate: '',
};

async function adminFetch(path: string, opts?: RequestInit) {
  const res = await fetch(`${BASE}/api${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', 'x-admin-token': ADMIN_TOKEN, ...opts?.headers },
  });
  if (res.status === 204) return null;
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

type Drop = {
  id: number; name: string; description: string; price: number;
  originalPrice: number | null; imageUrl: string; category: string;
  brand: string; sizes: string[]; colors: string[]; stock: number;
  status: string; featured: boolean; dropDate: string | null; endDate: string | null;
};

type Stats = { total: number; live: number; upcoming: number; soldOut: number; featured: number };

export default function Admin() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Drop | null>(null);
  const [form, setForm] = useState({ ...emptyForm });
  const [deleteId, setDeleteId] = useState<number | null>(null);
  const [sortField, setSortField] = useState<'name' | 'price' | 'stock' | 'status'>('name');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const { data: drops = [], isLoading } = useQuery<Drop[]>({
    queryKey: ['admin-drops'],
    queryFn: () => adminFetch('/admin/drops'),
  });

  const { data: stats } = useQuery<Stats>({
    queryKey: ['admin-stats'],
    queryFn: () => adminFetch('/admin/stats'),
  });

  const saveMutation = useMutation({
    mutationFn: (data: any) =>
      editing
        ? adminFetch(`/admin/drops/${editing.id}`, { method: 'PATCH', body: JSON.stringify(data) })
        : adminFetch('/admin/drops', { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin-drops'] });
      qc.invalidateQueries({ queryKey: ['admin-stats'] });
      toast({ title: editing ? 'تم التعديل' : 'تمت الإضافة' });
      closeForm();
    },
    onError: (e: any) => toast({ title: 'خطأ', description: e.message, variant: 'destructive' }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: number) => adminFetch(`/admin/drops/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin-drops'] });
      qc.invalidateQueries({ queryKey: ['admin-stats'] });
      toast({ title: 'تم الحذف' });
      setDeleteId(null);
    },
    onError: (e: any) => toast({ title: 'خطأ', description: e.message, variant: 'destructive' }),
  });

  function openAdd() {
    setEditing(null);
    setForm({ ...emptyForm });
    setShowForm(true);
  }

  function openEdit(d: Drop) {
    setEditing(d);
    setForm({
      name: d.name, description: d.description, price: String(d.price),
      originalPrice: d.originalPrice ? String(d.originalPrice) : '',
      imageUrl: d.imageUrl, category: d.category, brand: d.brand,
      sizes: d.sizes.join(', '), colors: d.colors.join(', '),
      stock: String(d.stock), status: d.status as any, featured: d.featured,
      dropDate: d.dropDate ? d.dropDate.slice(0, 16) : '',
      endDate: d.endDate ? d.endDate.slice(0, 16) : '',
    });
    setShowForm(true);
  }

  function closeForm() { setShowForm(false); setEditing(null); }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    saveMutation.mutate({
      name: form.name, description: form.description,
      price: parseFloat(form.price),
      originalPrice: form.originalPrice ? parseFloat(form.originalPrice) : null,
      imageUrl: form.imageUrl, category: form.category, brand: form.brand,
      sizes: form.sizes.split(',').map(s => s.trim()).filter(Boolean),
      colors: form.colors.split(',').map(s => s.trim()).filter(Boolean),
      stock: parseInt(form.stock), status: form.status, featured: form.featured,
      dropDate: form.dropDate || null, endDate: form.endDate || null,
    });
  }

  function toggleSort(field: typeof sortField) {
    if (sortField === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDir('asc'); }
  }

  const sorted = [...drops].sort((a, b) => {
    let va: any = a[sortField], vb: any = b[sortField];
    if (typeof va === 'string') va = va.toLowerCase(), vb = vb.toLowerCase();
    return sortDir === 'asc' ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1);
  });

  const SortIcon = ({ field }: { field: typeof sortField }) =>
    sortField === field
      ? (sortDir === 'asc' ? <ChevronUp className="w-3 h-3 inline" /> : <ChevronDown className="w-3 h-3 inline" />)
      : null;

  const inputCls = "w-full border border-border bg-background px-3 py-2 font-sans text-sm text-foreground focus:outline-none focus:border-foreground transition-colors";
  const labelCls = "block font-sans text-[10px] uppercase tracking-[0.15em] text-muted-foreground mb-1.5";

  return (
    <Layout>
      <div className="pt-24 min-h-screen">
        <div className="max-w-7xl mx-auto px-6 py-10">

          {/* Header */}
          <div className="flex items-center justify-between mb-10 border-b border-border pb-6">
            <div>
              <p className="font-sans text-[10px] uppercase tracking-[0.3em] text-primary mb-1">EMMA GLAM</p>
              <h1 className="font-serif font-light text-4xl text-foreground">لوحة التحكم</h1>
            </div>
            <Button onClick={openAdd} className="font-sans text-[10px] uppercase tracking-[0.2em] rounded-none bg-foreground text-background hover:bg-foreground/80 flex items-center gap-2 h-10 px-5">
              <Plus className="w-3.5 h-3.5" /> إضافة قطعة
            </Button>
          </div>

          {/* Stats */}
          {stats && (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
              {[
                { label: 'إجمالي القطع', value: stats.total, icon: Package },
                { label: 'متوفرة الآن', value: stats.live, icon: TrendingUp },
                { label: 'قادمة', value: stats.upcoming, icon: Clock },
                { label: 'نفدت', value: stats.soldOut, icon: X },
                { label: 'مميزة', value: stats.featured, icon: Star },
              ].map(({ label, value, icon: Icon }) => (
                <div key={label} className="border border-border bg-card p-5 flex flex-col gap-2">
                  <Icon className="w-4 h-4 text-muted-foreground" />
                  <p className="font-serif text-3xl text-foreground">{value}</p>
                  <p className="font-sans text-[10px] uppercase tracking-[0.15em] text-muted-foreground">{label}</p>
                </div>
              ))}
            </div>
          )}

          {/* Table */}
          <div className="border border-border overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border bg-secondary/30">
                  <th className="px-4 py-3 text-right">
                    <button onClick={() => toggleSort('name')} className="font-sans text-[10px] uppercase tracking-[0.15em] text-muted-foreground hover:text-foreground flex items-center gap-1">
                      الاسم <SortIcon field="name" />
                    </button>
                  </th>
                  <th className="px-4 py-3 text-right font-sans text-[10px] uppercase tracking-[0.15em] text-muted-foreground">القسم</th>
                  <th className="px-4 py-3 text-right">
                    <button onClick={() => toggleSort('price')} className="font-sans text-[10px] uppercase tracking-[0.15em] text-muted-foreground hover:text-foreground flex items-center gap-1">
                      السعر <SortIcon field="price" />
                    </button>
                  </th>
                  <th className="px-4 py-3 text-right">
                    <button onClick={() => toggleSort('stock')} className="font-sans text-[10px] uppercase tracking-[0.15em] text-muted-foreground hover:text-foreground flex items-center gap-1">
                      الكمية <SortIcon field="stock" />
                    </button>
                  </th>
                  <th className="px-4 py-3 text-right">
                    <button onClick={() => toggleSort('status')} className="font-sans text-[10px] uppercase tracking-[0.15em] text-muted-foreground hover:text-foreground flex items-center gap-1">
                      الحالة <SortIcon field="status" />
                    </button>
                  </th>
                  <th className="px-4 py-3 text-right font-sans text-[10px] uppercase tracking-[0.15em] text-muted-foreground">مميزة</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i} className="border-b border-border/50">
                      {Array.from({ length: 7 }).map((_, j) => (
                        <td key={j} className="px-4 py-4"><div className="h-4 bg-muted animate-pulse rounded" /></td>
                      ))}
                    </tr>
                  ))
                ) : sorted.map((drop) => (
                  <tr key={drop.id} className="border-b border-border/50 hover:bg-secondary/20 transition-colors group">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <img src={drop.imageUrl} alt={drop.name} className="w-10 h-12 object-cover border border-border rounded-md flex-shrink-0" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                        <span className="font-serif text-sm text-foreground">{drop.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-sans text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                        {categories.find(c => c.value === drop.category)?.label || drop.category}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-sans text-sm text-foreground">{drop.price.toLocaleString('en-US')} ر.س</td>
                    <td className="px-4 py-3 font-sans text-sm text-foreground">{drop.stock}</td>
                    <td className="px-4 py-3">
                      <span className={`font-sans text-[9px] uppercase tracking-[0.15em] px-2 py-1 ${
                        drop.status === 'live' ? 'bg-primary/10 text-primary' :
                        drop.status === 'upcoming' ? 'bg-muted text-muted-foreground' :
                        'bg-destructive/10 text-destructive'
                      }`}>
                        {drop.status === 'live' ? 'متوفر' : drop.status === 'upcoming' ? 'قادم' : 'نفد'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      {drop.featured && <Star className="w-4 h-4 text-primary fill-primary" />}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity justify-end">
                        <button onClick={() => openEdit(drop)} className="p-1.5 text-muted-foreground hover:text-foreground transition-colors">
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => setDeleteId(drop.id)} className="p-1.5 text-muted-foreground hover:text-destructive transition-colors">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!isLoading && drops.length === 0 && (
              <div className="py-20 text-center">
                <p className="font-serif text-xl text-muted-foreground mb-2">لا توجد قطع بعد</p>
                <button onClick={openAdd} className="font-sans text-[10px] uppercase tracking-[0.2em] text-primary hover:underline mt-2">أضيفي قطعتك الأولى</button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showForm && (
        <div className="fixed inset-0 z-[70] bg-foreground/30 backdrop-blur-sm flex items-start justify-center overflow-y-auto py-10 px-4">
          <div className="bg-background border border-border w-full max-w-2xl">
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <h2 className="font-serif font-light text-xl text-foreground">
                {editing ? 'تعديل القطعة' : 'إضافة قطعة جديدة'}
              </h2>
              <button onClick={closeForm} className="text-muted-foreground hover:text-foreground transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="md:col-span-2">
                <label className={labelCls}>اسم القطعة *</label>
                <input required className={inputCls} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="مثال: فستان سهرة بالمخمل الأسود" />
              </div>

              <div className="md:col-span-2">
                <label className={labelCls}>الوصف *</label>
                <textarea required rows={3} className={inputCls} value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="اكتبي وصفاً جذاباً للقطعة..." />
              </div>

              <div>
                <label className={labelCls}>رابط الصورة *</label>
                <input required className={inputCls} value={form.imageUrl} onChange={e => setForm(f => ({ ...f, imageUrl: e.target.value }))} placeholder="https://..." />
              </div>

              <div>
                <label className={labelCls}>القسم *</label>
                <select required className={inputCls} value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                  {categories.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
                </select>
              </div>

              <div>
                <label className={labelCls}>السعر (USD) *</label>
                <input required type="number" min="0" step="0.01" className={inputCls} value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="0.00" />
              </div>

              <div>
                <label className={labelCls}>السعر الأصلي قبل الخصم (اختياري)</label>
                <input type="number" min="0" step="0.01" className={inputCls} value={form.originalPrice} onChange={e => setForm(f => ({ ...f, originalPrice: e.target.value }))} placeholder="0.00" />
              </div>

              <div>
                <label className={labelCls}>البراند</label>
                <input className={inputCls} value={form.brand} onChange={e => setForm(f => ({ ...f, brand: e.target.value }))} />
              </div>

              <div>
                <label className={labelCls}>الكمية المتوفرة *</label>
                <input required type="number" min="0" className={inputCls} value={form.stock} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))} />
              </div>

              <div>
                <label className={labelCls}>المقاسات (مفصولة بفاصلة)</label>
                <input className={inputCls} value={form.sizes} onChange={e => setForm(f => ({ ...f, sizes: e.target.value }))} placeholder="XS, S, M, L, XL" />
              </div>

              <div>
                <label className={labelCls}>الألوان (مفصولة بفاصلة)</label>
                <input className={inputCls} value={form.colors} onChange={e => setForm(f => ({ ...f, colors: e.target.value }))} placeholder="أسود, أبيض, بيج" />
              </div>

              <div>
                <label className={labelCls}>الحالة *</label>
                <select required className={inputCls} value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value as any }))}>
                  <option value="live">متوفر الآن</option>
                  <option value="upcoming">قادم قريباً</option>
                  <option value="sold_out">نفدت الكمية</option>
                </select>
              </div>

              <div>
                <label className={labelCls}>تاريخ النزول (اختياري)</label>
                <input type="datetime-local" className={inputCls} value={form.dropDate} onChange={e => setForm(f => ({ ...f, dropDate: e.target.value }))} />
              </div>

              <div>
                <label className={labelCls}>تاريخ الانتهاء (اختياري)</label>
                <input type="datetime-local" className={inputCls} value={form.endDate} onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))} />
              </div>

              <div className="md:col-span-2 flex items-center gap-3">
                <input type="checkbox" id="featured" checked={form.featured} onChange={e => setForm(f => ({ ...f, featured: e.target.checked }))} className="w-4 h-4 accent-primary" />
                <label htmlFor="featured" className="font-sans text-sm text-foreground cursor-pointer">عرضها في القسم المميز في الصفحة الرئيسية</label>
              </div>

              {form.imageUrl && (
                <div className="md:col-span-2">
                  <label className={labelCls}>معاينة الصورة</label>
                  <img src={form.imageUrl} alt="preview" className="h-40 object-cover border border-border rounded-lg" onError={e => (e.target as HTMLImageElement).style.display = 'none'} />
                </div>
              )}

              <div className="md:col-span-2 flex gap-3 pt-2 border-t border-border mt-2">
                <Button type="submit" disabled={saveMutation.isPending} className="font-sans text-[10px] uppercase tracking-[0.2em] rounded-none bg-foreground text-background hover:bg-foreground/80 h-11 px-8">
                  {saveMutation.isPending ? '...' : (editing ? 'حفظ التعديلات' : 'إضافة القطعة')}
                </Button>
                <Button type="button" variant="outline" onClick={closeForm} className="font-sans text-[10px] uppercase tracking-[0.2em] rounded-none h-11 px-6">
                  إلغاء
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteId !== null && (
        <div className="fixed inset-0 z-[80] bg-foreground/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-background border border-border p-8 max-w-sm w-full text-center">
            <h3 className="font-serif text-xl text-foreground mb-3">تأكيد الحذف</h3>
            <p className="font-sans text-sm text-muted-foreground mb-6">هل أنتِ متأكدة؟ لا يمكن التراجع عن هذا الإجراء.</p>
            <div className="flex gap-3 justify-center">
              <Button onClick={() => deleteMutation.mutate(deleteId)} disabled={deleteMutation.isPending} className="rounded-none bg-destructive text-white hover:bg-destructive/80 font-sans text-[10px] uppercase tracking-[0.2em] h-10 px-6">
                {deleteMutation.isPending ? '...' : 'نعم، احذفي'}
              </Button>
              <Button variant="outline" onClick={() => setDeleteId(null)} className="rounded-none font-sans text-[10px] uppercase tracking-[0.2em] h-10 px-6">
                إلغاء
              </Button>
            </div>
          </div>
        </div>
      )}
    </Layout>
  );
}
