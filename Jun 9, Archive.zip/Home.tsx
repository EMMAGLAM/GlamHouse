import React from 'react';
import { Link } from 'wouter';
import { useListDrops } from '@workspace/api-client-react';
import { Layout } from '@/components/layout/Layout';
import { DropCard } from '@/components/DropCard';
import { CountdownTimer } from '@/components/CountdownTimer';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowRight } from 'lucide-react';
import { useLang } from '@/lib/i18n';
import { Logo } from '@/components/layout/Logo';
import { departments, type CategoryDef } from '@/lib/departments';

export default function Home() {
  const { t } = useLang();
  const { data: allDrops } = useListDrops({});
  const { data: liveDrops, isLoading: isLoadingLive } = useListDrops({ status: 'live' });
  const { data: upcomingDrops } = useListDrops({ status: 'upcoming' });

  // Map each category slug -> a representative product image (first one found).
  const catImage = React.useMemo(() => {
    const m: Record<string, string> = {};
    (allDrops ?? []).forEach((d) => {
      if (d.imageUrl && d.category && !m[d.category]) m[d.category] = d.imageUrl;
    });
    return m;
  }, [allDrops]);

  const renderTile = (cat: CategoryDef) => (
    <Link
      key={cat.slug}
      href={`/drops?category=${cat.slug}`}
      className="group relative block overflow-hidden bg-secondary/20"
    >
      <div className="relative aspect-[4/5]">
        <img
          src={catImage[cat.slug] || '/images/drop-dress.png'}
          alt={cat.en}
          onError={(e) => {
            const img = e.currentTarget;
            if (!img.src.endsWith('/images/drop-dress.png')) img.src = '/images/drop-dress.png';
          }}
          className="absolute inset-0 w-full h-full object-cover object-top transition-transform duration-[1200ms] group-hover:scale-105 motion-reduce:transition-none"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/55 via-foreground/5 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-5 md:p-7">
          <span className="block font-sans text-[9px] uppercase tracking-[0.25em] text-background/75 mb-1.5">
            {cat.en}
          </span>
          <h3 className="font-serif font-light text-background leading-tight" style={{ fontSize: 'clamp(1.3rem, 2.4vw, 2rem)' }}>
            {t(cat.arKey)}
          </h3>
        </div>
      </div>
    </Link>
  );

  return (
    <Layout>
      <div className="pt-0 md:pt-24">

        {/* ── HERO — split layout with poster ── */}
        <section className="relative min-h-[92vh] flex overflow-hidden bg-background -mt-[80px] md:mt-0">

          {/* LEFT: Poster image — full height, portrait */}
          <div className="hidden md:block w-[42%] relative flex-shrink-0">
            <img
              src="/poster-hero.png"
              alt="EMMA GLAM Editorial"
              className="absolute inset-0 w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-transparent to-background/60" />
          </div>

          {/* RIGHT: Text content centered */}
          <div className="flex-1 flex flex-col items-center justify-start md:justify-center px-8 md:px-16 text-center relative">

            <span
              aria-hidden="true"
              className="pointer-events-none select-none absolute inset-0 flex items-center justify-center font-serif font-light leading-none text-foreground/[0.035]"
              style={{ fontSize: 'clamp(6rem, 16vw, 16rem)', letterSpacing: '-0.02em' }}
            >
              GLAM
            </span>

            {/* mobile poster — full-bleed editorial with brand wordmark */}
            <div className="md:hidden relative left-1/2 -translate-x-1/2 w-screen h-[68vh] mb-8">
              <img
                src="/poster-hero.png"
                alt="EMMA GLAM Editorial"
                className="w-full h-full object-cover object-[center_top]"
              />
              <div className="absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-b from-transparent to-background" />
              <div className="absolute inset-x-0 bottom-7 flex justify-center px-8">
                <Logo size="text-4xl" />
              </div>
            </div>

            <div className="relative z-10 flex flex-col items-center gap-7 max-w-lg mx-auto">
              <p className="font-sans text-[10px] uppercase tracking-[0.08em] text-primary">
                {t('heroTagline')}
              </p>

              <h1
                className="hidden md:block font-serif font-light text-foreground leading-[0.9]"
                style={{ fontSize: 'clamp(4rem, 10vw, 9rem)', letterSpacing: '-0.02em' }}
              >
                {t('heroTitle1')}<br />
                <em style={{ fontStyle: 'italic' }}>{t('heroTitle2')}</em>
              </h1>

              <p className="font-sans font-light text-muted-foreground text-sm tracking-wide max-w-xs leading-relaxed">
                {t('heroDesc')}
              </p>

              <div className="flex items-center gap-8 mt-2">
                <Link
                  href="/drops"
                  className="group font-sans text-[11px] uppercase tracking-[0.25em] text-foreground border-b border-foreground pb-0.5 hover:text-primary hover:border-primary transition-colors flex items-center gap-2"
                >
                  {t('browseAll')}
                  <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </Link>
                <Link
                  href="/drops?status=upcoming"
                  className="font-sans text-[11px] uppercase tracking-[0.25em] text-muted-foreground hover:text-foreground transition-colors"
                >
                  {t('upcomingDrops')}
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* ── EDITORIAL STATEMENT ── */}
        <section className="relative overflow-hidden bg-background border-t border-border">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 md:min-h-[65vh]">
            <div className="flex flex-col justify-center items-center text-center px-10 md:px-16 py-16 md:py-20 bg-background order-2 md:order-1">
              <p className="font-sans text-[9px] uppercase tracking-[0.4em] text-primary mb-6">
                EMMA GLAM — {new Date().getFullYear()}
              </p>
              <p className="font-sans font-light text-muted-foreground text-sm tracking-wide leading-loose mb-10 whitespace-pre-line">
                {t('brandStatement')}
              </p>
              <Link
                href="/drops"
                className="group inline-flex items-center gap-3 font-sans text-[11px] uppercase tracking-[0.3em] text-foreground border-b border-foreground pb-1 hover:text-primary hover:border-primary transition-colors self-center"
              >
                {t('enterWardrobe')}
                <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            <div className="relative overflow-hidden h-[100vw] md:h-auto md:min-h-0 order-1 md:order-2">
              <img
                src="/poster-editorial.png"
                alt="EMMA GLAM Editorial"
                className="absolute inset-0 w-full h-full object-cover object-[center_20%]"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-background/10 via-transparent to-background/10" />
            </div>
          </div>
        </section>

        {/* ── DEPARTMENTS — Women & Men, visual category tiles ── */}
        <section className="py-24 md:py-28 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16 md:mb-20">
              <p className="font-sans text-[10px] uppercase tracking-[0.3em] text-primary mb-3">{t('wardrobeTagline')}</p>
              <h2 className="font-serif font-light text-foreground" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
                {t('theWardrobe')}
              </h2>
              <p className="font-sans font-light text-muted-foreground text-sm tracking-wide mt-5 max-w-md mx-auto leading-relaxed">
                {t('wardrobeDesc')}
              </p>
            </div>

            {departments.map((dep) => {
              const tiles = dep.categories.filter((c) => catImage[c.slug]);
              if (tiles.length === 0) return null;
              return (
                <div key={dep.id} className="mb-16 md:mb-20 last:mb-0">
                  <div className="flex items-baseline justify-between mb-8 border-b border-border pb-5">
                    <h3 className="font-serif font-light text-foreground" style={{ fontSize: 'clamp(1.6rem, 3vw, 2.6rem)' }}>
                      {t(dep.labelKey)}
                    </h3>
                    <Link
                      href={`/drops?category=${tiles[0].slug}`}
                      className="group font-sans text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-primary transition-colors flex items-center gap-1.5"
                    >
                      {t('viewAll')}
                      <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                    </Link>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-5">
                    {tiles.map(renderTile)}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* ── LIVE NOW ── */}
        <section className="py-24 px-6 bg-secondary/20">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-baseline justify-between mb-16 border-b border-border pb-6">
              <div>
                <p className="font-sans text-[10px] uppercase tracking-[0.3em] text-primary mb-2">{t('availableNow')}</p>
                <h2 className="font-serif font-light text-foreground" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
                  {t('liveNow')}
                </h2>
              </div>
              <Link href="/drops?status=live" className="group font-sans text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-primary transition-colors flex items-center gap-1.5">
                {t('seeAll')} <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-x-8 gap-y-14">
              {isLoadingLive
                ? Array.from({ length: 8 }).map((_, i) => (
                    <div key={i} className="flex flex-col gap-3">
                      <Skeleton className="w-full aspect-[3/4] rounded-2xl" />
                      <Skeleton className="h-4 w-2/3" />
                      <Skeleton className="h-3 w-1/3" />
                    </div>
                  ))
                : liveDrops?.slice(0, 8).map((drop) => (
                    <DropCard key={drop.id} drop={drop} />
                  ))}
            </div>
          </div>
        </section>

        {/* ── UPCOMING ── */}
        {upcomingDrops && upcomingDrops.length > 0 && (
          <section className="py-24 px-6">
            <div className="max-w-6xl mx-auto">
              <div className="flex items-baseline justify-between mb-16 border-b border-border pb-6">
                <div>
                  <p className="font-sans text-[10px] uppercase tracking-[0.3em] text-muted-foreground mb-2">{t('comingSoon')}</p>
                  <h2 className="font-serif font-light text-foreground" style={{ fontSize: 'clamp(2rem, 4vw, 3.5rem)' }}>
                    {t('upcomingReleases')}
                  </h2>
                </div>
                <Link href="/drops?status=upcoming" className="group font-sans text-[10px] uppercase tracking-[0.25em] text-muted-foreground hover:text-primary transition-colors flex items-center gap-1.5">
                  {t('seeAll')} <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </Link>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-14">
                {upcomingDrops.slice(0, 3).map((drop) => (
                  <div key={drop.id} className="flex flex-col gap-4">
                    <DropCard drop={drop} />
                    {drop.dropDate && (
                      <div className="border-t border-border pt-4">
                        <p className="font-sans text-[9px] uppercase tracking-[0.25em] text-muted-foreground mb-2">{t('droppingIn')}</p>
                        <CountdownTimer targetDate={drop.dropDate} className="font-sans text-sm tracking-wider" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* ── BRAND STATEMENT ── */}
        <section className="py-32 px-6 border-t border-border text-center">
          <div className="max-w-2xl mx-auto">
            <p className="font-sans font-light text-muted-foreground text-sm tracking-wide leading-relaxed mb-10">
              {t('brandStatement')}
            </p>
            <Link
              href="/drops"
              className="group inline-flex items-center gap-3 font-sans text-[11px] uppercase tracking-[0.3em] text-foreground border-b border-foreground pb-1 hover:text-primary hover:border-primary transition-colors"
            >
              {t('enterWardrobe')}
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </section>

      </div>
    </Layout>
  );
}
