import { useState } from 'react';
import { Truck, RotateCcw, ChevronDown } from 'lucide-react';
import { useLang } from '@/lib/i18n';

export function ShippingReturns() {
  const { t } = useLang();
  const [open, setOpen] = useState(false);

  const steps = [t('returnsStep1'), t('returnsStep2'), t('returnsStep3')];

  return (
    <div className="border-y border-border divide-y divide-border">
      {/* delivery estimate */}
      <div className="flex items-start gap-4 py-5">
        <Truck className="w-5 h-5 text-primary shrink-0 mt-0.5" />
        <div>
          <p className="font-sans text-[11px] uppercase tracking-[0.2em] text-foreground mb-1">
            {t('deliveryTitle')}
          </p>
          <p className="text-sm text-muted-foreground font-light">{t('deliveryTime')}</p>
        </div>
      </div>

      {/* returns & exchange mechanism */}
      <div className="py-5">
        <button
          type="button"
          onClick={() => setOpen((o) => !o)}
          aria-expanded={open}
          aria-controls="returns-panel"
          className="w-full flex items-center gap-4 text-start"
        >
          <RotateCcw className="w-5 h-5 text-primary shrink-0" />
          <span className="font-sans text-[11px] uppercase tracking-[0.2em] text-foreground flex-1">
            {t('returnsTitle')}
          </span>
          <ChevronDown
            className={`w-4 h-4 text-muted-foreground transition-transform ${open ? 'rotate-180' : ''}`}
          />
        </button>

        {open && (
          <div id="returns-panel" role="region" className="ps-9 pt-4 space-y-3">
            <p className="text-sm text-muted-foreground font-light leading-relaxed">
              {t('returnsIntro')}
            </p>
            <ol className="space-y-2.5">
              {steps.map((step, i) => (
                <li key={i} className="flex gap-3 text-sm text-foreground/80 font-light">
                  <span className="font-serif text-primary">{i + 1}</span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
            <p className="text-xs text-muted-foreground/80 font-light pt-1">{t('returnsWindow')}</p>
          </div>
        )}
      </div>
    </div>
  );
}
