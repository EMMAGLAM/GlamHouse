import React from 'react';
import { Navbar } from './Navbar';
import { Footer } from './Footer';
import { MusicToggle } from '@/components/MusicToggle';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground selection:bg-primary selection:text-primary-foreground">
      <Navbar />
      <main className="flex-1 w-full mt-[80px]">
        {children}
      </main>
      <Footer />
      <MusicToggle />
    </div>
  );
}
