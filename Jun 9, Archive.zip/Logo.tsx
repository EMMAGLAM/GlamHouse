import React from 'react';

interface LogoProps {
  className?: string;
  size?: string;
}

export function Logo({ className = '', size = 'text-xl' }: LogoProps) {
  return (
    <span
      dir="ltr"
      className={`inline-flex items-center font-serif leading-none ${size} ${className}`}
    >
      <span
        className="font-normal text-foreground"
        style={{ letterSpacing: '0.24em', textIndent: '0.24em' }}
      >
        EMMA
      </span>
      <span
        aria-hidden="true"
        className="mx-[0.55em] w-[3px] h-[3px] rotate-45 bg-primary/70 shrink-0"
      />
      <span
        className="font-light italic text-primary"
        style={{ letterSpacing: '0.06em' }}
      >
        GLAM
      </span>
    </span>
  );
}
