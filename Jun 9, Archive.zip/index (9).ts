import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dropsRouter from "./drops";
import cartRouter from "./cart";
import wishlistRouter from "./wishlist";
import adminRouter from "./admin";
import shopifyRouter from "./shopify";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dropsRouter);
router.use(cartRouter);
router.use(wishlistRouter);
router.use(adminRouter);
router.use(shopifyRouter);

export default router;
