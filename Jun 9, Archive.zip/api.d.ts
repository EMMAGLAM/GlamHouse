import type { QueryKey, UseMutationOptions, UseMutationResult, UseQueryOptions, UseQueryResult } from '@tanstack/react-query';
import type { Cart, CartItem, CartItemInput, CartItemUpdate, Category, Drop, DropStats, ErrorResponse, HealthStatus, ListDropsParams, WishlistItem } from './api.schemas';
import { customFetch } from '../custom-fetch';
import type { ErrorType, BodyType } from '../custom-fetch';
type AwaitedInput<T> = PromiseLike<T> | T;
type Awaited<O> = O extends AwaitedInput<infer T> ? T : never;
type SecondParameter<T extends (...args: never) => unknown> = Parameters<T>[1];
export declare const getHealthCheckUrl: () => string;
/**
 * Returns server health status
 * @summary Health check
 */
export declare const healthCheck: (options?: RequestInit) => Promise<HealthStatus>;
export declare const getHealthCheckQueryKey: () => readonly ["/api/healthz"];
export declare const getHealthCheckQueryOptions: <TData = Awaited<ReturnType<typeof healthCheck>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof healthCheck>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof healthCheck>>, TError, TData> & {
    queryKey: QueryKey;
};
export type HealthCheckQueryResult = NonNullable<Awaited<ReturnType<typeof healthCheck>>>;
export type HealthCheckQueryError = ErrorType<unknown>;
/**
 * @summary Health check
 */
export declare function useHealthCheck<TData = Awaited<ReturnType<typeof healthCheck>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof healthCheck>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getListDropsUrl: (params?: ListDropsParams) => string;
/**
 * @summary List all drops
 */
export declare const listDrops: (params?: ListDropsParams, options?: RequestInit) => Promise<Drop[]>;
export declare const getListDropsQueryKey: (params?: ListDropsParams) => readonly ["/api/drops", ...ListDropsParams[]];
export declare const getListDropsQueryOptions: <TData = Awaited<ReturnType<typeof listDrops>>, TError = ErrorType<unknown>>(params?: ListDropsParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listDrops>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listDrops>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListDropsQueryResult = NonNullable<Awaited<ReturnType<typeof listDrops>>>;
export type ListDropsQueryError = ErrorType<unknown>;
/**
 * @summary List all drops
 */
export declare function useListDrops<TData = Awaited<ReturnType<typeof listDrops>>, TError = ErrorType<unknown>>(params?: ListDropsParams, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listDrops>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getGetFeaturedDropsUrl: () => string;
/**
 * @summary Get featured drops for the hero
 */
export declare const getFeaturedDrops: (options?: RequestInit) => Promise<Drop[]>;
export declare const getGetFeaturedDropsQueryKey: () => readonly ["/api/drops/featured"];
export declare const getGetFeaturedDropsQueryOptions: <TData = Awaited<ReturnType<typeof getFeaturedDrops>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getFeaturedDrops>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getFeaturedDrops>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetFeaturedDropsQueryResult = NonNullable<Awaited<ReturnType<typeof getFeaturedDrops>>>;
export type GetFeaturedDropsQueryError = ErrorType<unknown>;
/**
 * @summary Get featured drops for the hero
 */
export declare function useGetFeaturedDrops<TData = Awaited<ReturnType<typeof getFeaturedDrops>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getFeaturedDrops>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getGetDropStatsUrl: () => string;
/**
 * @summary Get drop stats summary
 */
export declare const getDropStats: (options?: RequestInit) => Promise<DropStats>;
export declare const getGetDropStatsQueryKey: () => readonly ["/api/drops/stats"];
export declare const getGetDropStatsQueryOptions: <TData = Awaited<ReturnType<typeof getDropStats>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getDropStats>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getDropStats>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetDropStatsQueryResult = NonNullable<Awaited<ReturnType<typeof getDropStats>>>;
export type GetDropStatsQueryError = ErrorType<unknown>;
/**
 * @summary Get drop stats summary
 */
export declare function useGetDropStats<TData = Awaited<ReturnType<typeof getDropStats>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getDropStats>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getGetDropUrl: (id: number) => string;
/**
 * @summary Get a single drop
 */
export declare const getDrop: (id: number, options?: RequestInit) => Promise<Drop>;
export declare const getGetDropQueryKey: (id: number) => readonly [`/api/drops/${number}`];
export declare const getGetDropQueryOptions: <TData = Awaited<ReturnType<typeof getDrop>>, TError = ErrorType<ErrorResponse>>(id: number, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getDrop>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getDrop>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetDropQueryResult = NonNullable<Awaited<ReturnType<typeof getDrop>>>;
export type GetDropQueryError = ErrorType<ErrorResponse>;
/**
 * @summary Get a single drop
 */
export declare function useGetDrop<TData = Awaited<ReturnType<typeof getDrop>>, TError = ErrorType<ErrorResponse>>(id: number, options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getDrop>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getListCategoriesUrl: () => string;
/**
 * @summary List all categories
 */
export declare const listCategories: (options?: RequestInit) => Promise<Category[]>;
export declare const getListCategoriesQueryKey: () => readonly ["/api/categories"];
export declare const getListCategoriesQueryOptions: <TData = Awaited<ReturnType<typeof listCategories>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listCategories>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof listCategories>>, TError, TData> & {
    queryKey: QueryKey;
};
export type ListCategoriesQueryResult = NonNullable<Awaited<ReturnType<typeof listCategories>>>;
export type ListCategoriesQueryError = ErrorType<unknown>;
/**
 * @summary List all categories
 */
export declare function useListCategories<TData = Awaited<ReturnType<typeof listCategories>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof listCategories>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getGetCartUrl: () => string;
/**
 * @summary Get cart contents
 */
export declare const getCart: (options?: RequestInit) => Promise<Cart>;
export declare const getGetCartQueryKey: () => readonly ["/api/cart"];
export declare const getGetCartQueryOptions: <TData = Awaited<ReturnType<typeof getCart>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getCart>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getCart>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetCartQueryResult = NonNullable<Awaited<ReturnType<typeof getCart>>>;
export type GetCartQueryError = ErrorType<unknown>;
/**
 * @summary Get cart contents
 */
export declare function useGetCart<TData = Awaited<ReturnType<typeof getCart>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getCart>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getAddToCartUrl: () => string;
/**
 * @summary Add item to cart
 */
export declare const addToCart: (cartItemInput: CartItemInput, options?: RequestInit) => Promise<CartItem>;
export declare const getAddToCartMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof addToCart>>, TError, {
        data: BodyType<CartItemInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof addToCart>>, TError, {
    data: BodyType<CartItemInput>;
}, TContext>;
export type AddToCartMutationResult = NonNullable<Awaited<ReturnType<typeof addToCart>>>;
export type AddToCartMutationBody = BodyType<CartItemInput>;
export type AddToCartMutationError = ErrorType<unknown>;
/**
* @summary Add item to cart
*/
export declare const useAddToCart: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof addToCart>>, TError, {
        data: BodyType<CartItemInput>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof addToCart>>, TError, {
    data: BodyType<CartItemInput>;
}, TContext>;
export declare const getUpdateCartItemUrl: (itemId: number) => string;
/**
 * @summary Update cart item quantity
 */
export declare const updateCartItem: (itemId: number, cartItemUpdate: CartItemUpdate, options?: RequestInit) => Promise<CartItem>;
export declare const getUpdateCartItemMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateCartItem>>, TError, {
        itemId: number;
        data: BodyType<CartItemUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof updateCartItem>>, TError, {
    itemId: number;
    data: BodyType<CartItemUpdate>;
}, TContext>;
export type UpdateCartItemMutationResult = NonNullable<Awaited<ReturnType<typeof updateCartItem>>>;
export type UpdateCartItemMutationBody = BodyType<CartItemUpdate>;
export type UpdateCartItemMutationError = ErrorType<unknown>;
/**
* @summary Update cart item quantity
*/
export declare const useUpdateCartItem: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateCartItem>>, TError, {
        itemId: number;
        data: BodyType<CartItemUpdate>;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof updateCartItem>>, TError, {
    itemId: number;
    data: BodyType<CartItemUpdate>;
}, TContext>;
export declare const getRemoveCartItemUrl: (itemId: number) => string;
/**
 * @summary Remove item from cart
 */
export declare const removeCartItem: (itemId: number, options?: RequestInit) => Promise<void>;
export declare const getRemoveCartItemMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof removeCartItem>>, TError, {
        itemId: number;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof removeCartItem>>, TError, {
    itemId: number;
}, TContext>;
export type RemoveCartItemMutationResult = NonNullable<Awaited<ReturnType<typeof removeCartItem>>>;
export type RemoveCartItemMutationError = ErrorType<unknown>;
/**
* @summary Remove item from cart
*/
export declare const useRemoveCartItem: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof removeCartItem>>, TError, {
        itemId: number;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof removeCartItem>>, TError, {
    itemId: number;
}, TContext>;
export declare const getGetWishlistUrl: () => string;
/**
 * @summary Get wishlist
 */
export declare const getWishlist: (options?: RequestInit) => Promise<WishlistItem[]>;
export declare const getGetWishlistQueryKey: () => readonly ["/api/wishlist"];
export declare const getGetWishlistQueryOptions: <TData = Awaited<ReturnType<typeof getWishlist>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getWishlist>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}) => UseQueryOptions<Awaited<ReturnType<typeof getWishlist>>, TError, TData> & {
    queryKey: QueryKey;
};
export type GetWishlistQueryResult = NonNullable<Awaited<ReturnType<typeof getWishlist>>>;
export type GetWishlistQueryError = ErrorType<unknown>;
/**
 * @summary Get wishlist
 */
export declare function useGetWishlist<TData = Awaited<ReturnType<typeof getWishlist>>, TError = ErrorType<unknown>>(options?: {
    query?: UseQueryOptions<Awaited<ReturnType<typeof getWishlist>>, TError, TData>;
    request?: SecondParameter<typeof customFetch>;
}): UseQueryResult<TData, TError> & {
    queryKey: QueryKey;
};
export declare const getAddToWishlistUrl: (dropId: number) => string;
/**
 * @summary Add drop to wishlist
 */
export declare const addToWishlist: (dropId: number, options?: RequestInit) => Promise<WishlistItem>;
export declare const getAddToWishlistMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof addToWishlist>>, TError, {
        dropId: number;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof addToWishlist>>, TError, {
    dropId: number;
}, TContext>;
export type AddToWishlistMutationResult = NonNullable<Awaited<ReturnType<typeof addToWishlist>>>;
export type AddToWishlistMutationError = ErrorType<unknown>;
/**
* @summary Add drop to wishlist
*/
export declare const useAddToWishlist: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof addToWishlist>>, TError, {
        dropId: number;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof addToWishlist>>, TError, {
    dropId: number;
}, TContext>;
export declare const getRemoveFromWishlistUrl: (dropId: number) => string;
/**
 * @summary Remove drop from wishlist
 */
export declare const removeFromWishlist: (dropId: number, options?: RequestInit) => Promise<void>;
export declare const getRemoveFromWishlistMutationOptions: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof removeFromWishlist>>, TError, {
        dropId: number;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationOptions<Awaited<ReturnType<typeof removeFromWishlist>>, TError, {
    dropId: number;
}, TContext>;
export type RemoveFromWishlistMutationResult = NonNullable<Awaited<ReturnType<typeof removeFromWishlist>>>;
export type RemoveFromWishlistMutationError = ErrorType<unknown>;
/**
* @summary Remove drop from wishlist
*/
export declare const useRemoveFromWishlist: <TError = ErrorType<unknown>, TContext = unknown>(options?: {
    mutation?: UseMutationOptions<Awaited<ReturnType<typeof removeFromWishlist>>, TError, {
        dropId: number;
    }, TContext>;
    request?: SecondParameter<typeof customFetch>;
}) => UseMutationResult<Awaited<ReturnType<typeof removeFromWishlist>>, TError, {
    dropId: number;
}, TContext>;
export {};
//# sourceMappingURL=api.d.ts.map