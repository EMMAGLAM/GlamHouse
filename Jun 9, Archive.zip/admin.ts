import { Router } from "express";
import { db } from "@workspace/db";
import { dropsTable, categoriesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { z } from "zod";

const router = Router();

const ADMIN_SECRET = process.env.ADMIN_SECRET || "emma-glam-admin-2024";

function requireAdmin(req: any, res: any, next: any) {
  const token = req.headers["x-admin-token"];
  if (token !== ADMIN_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

const dropSchema = z.object({
  name: z.string().min(1),
  description: z.string().min(1),
  price: z.number().positive(),
  originalPrice: z.number().positive().nullable().optional(),
  imageUrl: z.string().min(1),
  imageUrls: z.array(z.string()).optional(),
  category: z.string().min(1),
  brand: z.string().min(1),
  sizes: z.array(z.string()).optional(),
  colors: z.array(z.string()).optional(),
  stock: z.number().int().min(0),
  status: z.enum(["live", "upcoming", "sold_out"]),
  featured: z.boolean().optional(),
  dropDate: z.string().nullable().optional(),
  endDate: z.string().nullable().optional(),
  tags: z.array(z.string()).optional(),
});

router.get("/admin/drops", requireAdmin, async (req, res) => {
  const drops = await db.select().from(dropsTable).orderBy(dropsTable.createdAt);
  res.json(drops.map(d => ({
    ...d,
    price: parseFloat(d.price),
    originalPrice: d.originalPrice ? parseFloat(d.originalPrice) : null,
    dropDate: d.dropDate?.toISOString() ?? null,
    endDate: d.endDate?.toISOString() ?? null,
  })));
});

router.post("/admin/drops", requireAdmin, async (req, res) => {
  const parsed = dropSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid data", details: parsed.error.issues });
  }
  const data = parsed.data;
  const [drop] = await db.insert(dropsTable).values({
    name: data.name,
    description: data.description,
    price: String(data.price),
    originalPrice: data.originalPrice != null ? String(data.originalPrice) : null,
    imageUrl: data.imageUrl,
    imageUrls: data.imageUrls ?? [],
    category: data.category,
    brand: data.brand,
    sizes: data.sizes ?? [],
    colors: data.colors ?? [],
    stock: data.stock,
    status: data.status,
    featured: data.featured ?? false,
    dropDate: data.dropDate ? new Date(data.dropDate) : null,
    endDate: data.endDate ? new Date(data.endDate) : null,
    tags: data.tags ?? [],
  }).returning();
  return res.status(201).json(drop);
});

router.patch("/admin/drops/:id", requireAdmin, async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  const parsed = dropSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid data", details: parsed.error.issues });
  const data = parsed.data;
  const updateData: any = { ...data };
  if (data.price !== undefined) updateData.price = String(data.price);
  if (data.originalPrice !== undefined) updateData.originalPrice = data.originalPrice != null ? String(data.originalPrice) : null;
  if (data.dropDate !== undefined) updateData.dropDate = data.dropDate ? new Date(data.dropDate) : null;
  if (data.endDate !== undefined) updateData.endDate = data.endDate ? new Date(data.endDate) : null;
  const [updated] = await db.update(dropsTable).set(updateData).where(eq(dropsTable.id, id)).returning();
  if (!updated) return res.status(404).json({ error: "Drop not found" });
  return res.json(updated);
});

router.delete("/admin/drops/:id", requireAdmin, async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) return res.status(400).json({ error: "Invalid id" });
  await db.delete(dropsTable).where(eq(dropsTable.id, id));
  return res.status(204).send();
});

router.get("/admin/stats", requireAdmin, async (req, res) => {
  const drops = await db.select().from(dropsTable);
  res.json({
    total: drops.length,
    live: drops.filter(d => d.status === "live").length,
    upcoming: drops.filter(d => d.status === "upcoming").length,
    soldOut: drops.filter(d => d.status === "sold_out").length,
    featured: drops.filter(d => d.featured).length,
  });
});

export default router;
