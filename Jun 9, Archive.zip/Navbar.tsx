import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Heart, ShoppingBag, Menu, X, ChevronDown } from 'lucide-react';
import { useGetCart, useGetWishlist } from '@workspace/api-client-react';
import { useLang } from '@/lib/i18n';
import { departments } from '@/lib/departments';
import { Logo } from './Logo';

export function Navbar() {
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [openDept, setOpenDept] = useState<string | null>(null);
  const [expandedDept, setExpandedDept] = useState<string | null>(null);
  const { data: cart } = useGetCart();
  const { data: wishlist } = useGetWishlist();
  const { lang, setLang, t, isRTL } = useLang();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setOpenDept(null);
  }, [location]);

  useEffect(() => {
    if (!mobileMenuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMobileMenuOpen(false);
    };
    document.addEventListener('keydown', onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [mobileMenuOpen]);

  const closeMobile = () => {
    setMobileMenuOpen(false);
    setExpandedDept(null);
  };

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-background/97 backdrop-blur-md shadow-[0_1px_0_0_hsl(var(--border))]' : 'bg-background/80 backdrop-blur-sm'}`}>

        {/* top row */}
        <div className="flex items-center justify-between px-6 md:px-10 h-14">
          {/* mobile menu */}
          <button
            className="md:hidden text-foreground/60 hover:text-foreground"
            onClick={() => setMobileMenuOpen(true)}
            aria-label={t('menu')}
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-drawer"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* logo */}
          <Link href="/" className="mx-auto md:mx-0 hover:opacity-80 transition-opacity">
            <Logo size="text-xl" />
          </Link>

          {/* icons + lang toggle */}
          <div className="flex items-center gap-5 ml-auto">
            {/* Language toggle */}
            <button
              onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
              className="font-sans text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground transition-colors border border-border/60 px-2 py-1 leading-none"
              title={lang === 'ar' ? 'Switch to English' : 'التبديل للعربية'}
            >
              {lang === 'ar' ? 'EN' : 'ع'}
            </button>

            <Link href="/wishlist" className="relative text-foreground/60 hover:text-foreground transition-colors">
              <Heart style={{ width: '1.1rem', height: '1.1rem' }} />
              {(wishlist?.length ?? 0) > 0 && (
                <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-primary text-primary-foreground font-sans text-[7px] flex items-center justify-center">
                  {wishlist!.length}
                </span>
              )}
            </Link>
            <Link href="/cart" className="relative text-foreground/60 hover:text-foreground transition-colors">
              <ShoppingBag style={{ width: '1.1rem', height: '1.1rem' }} />
              {(cart?.itemCount ?? 0) > 0 && (
                <span className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-primary text-primary-foreground font-sans text-[7px] flex items-center justify-center">
                  {cart!.itemCount}
                </span>
              )}
            </Link>
          </div>
        </div>

        {/* department row — desktop */}
        <div className="hidden md:flex items-center justify-center gap-10 border-t border-border/50 h-10 px-10">
          <Link href="/drops" className="font-sans text-[10px] uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground transition-colors">
            {t('all')}
          </Link>
          {departments.map((dep) => (
            <div key={dep.id} className="relative h-full flex items-center">
              <button
                onClick={() => setOpenDept(openDept === dep.id ? null : dep.id)}
                aria-expanded={openDept === dep.id}
                className={`font-sans text-[10px] uppercase tracking-[0.2em] transition-colors inline-flex items-center gap-1.5 ${openDept === dep.id ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                {t(dep.labelKey)}
                <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${openDept === dep.id ? 'rotate-180' : ''}`} />
              </button>

              {openDept === dep.id && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 min-w-[210px] bg-background border border-border shadow-xl py-2 z-[60]">
                  {dep.categories.map((cat) => (
                    <Link
                      key={cat.slug}
                      href={`/drops?category=${cat.slug}`}
                      onClick={() => setOpenDept(null)}
                      className="block px-5 py-2.5 font-sans text-[11px] uppercase tracking-[0.15em] text-muted-foreground hover:text-primary hover:bg-secondary/40 transition-colors whitespace-nowrap text-center"
                    >
                      {t(cat.arKey)}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </nav>

      {/* desktop dropdown backdrop — closes on outside tap (iPad-friendly) */}
      {openDept && (
        <div
          className="hidden md:block fixed inset-0 z-40"
          onClick={() => setOpenDept(null)}
          aria-hidden="true"
        />
      )}

      {/* mobile side drawer — backdrop */}
      <div
        onClick={closeMobile}
        className={`md:hidden fixed inset-0 z-[60] bg-foreground/40 backdrop-blur-sm transition-opacity duration-300 ${mobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      />

      {/* mobile side drawer — panel */}
      <aside
        id="mobile-drawer"
        role="dialog"
        aria-modal="true"
        aria-label={t('menu')}
        {...(!mobileMenuOpen ? ({ inert: true } as any) : {})}
        className={`md:hidden fixed top-0 bottom-0 z-[70] w-[80%] max-w-xs bg-background flex flex-col shadow-2xl transition-transform duration-300 ease-out
          ${isRTL ? 'right-0 border-l border-border' : 'left-0 border-r border-border'}
          ${mobileMenuOpen ? 'translate-x-0' : isRTL ? 'translate-x-full' : '-translate-x-full'}`}
      >
        <div className="flex items-center justify-between px-6 h-14 border-b border-border shrink-0">
          <Logo size="text-lg" />
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
              className="font-sans text-[10px] uppercase tracking-[0.2em] text-muted-foreground border border-border/60 px-2 py-1"
            >
              {lang === 'ar' ? 'EN' : 'ع'}
            </button>
            <button onClick={closeMobile} aria-label={t('close')} className="text-foreground/60 hover:text-foreground">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto px-6 py-8 flex flex-col gap-2">
          <Link href="/drops" onClick={closeMobile} className="font-serif font-light text-xl tracking-wide text-foreground hover:text-primary transition-colors inline-flex items-center gap-2.5 mb-3">
            <Heart className="w-4 h-4 text-primary fill-primary" />
            {t('all')}
          </Link>

          {departments.map((dep) => (
            <div key={dep.id} className="border-t border-border/60 pt-3">
              <button
                onClick={() => setExpandedDept(expandedDept === dep.id ? null : dep.id)}
                aria-expanded={expandedDept === dep.id}
                className="w-full flex items-center justify-between font-serif font-light text-xl tracking-wide text-foreground hover:text-primary transition-colors"
              >
                {t(dep.labelKey)}
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${expandedDept === dep.id ? 'rotate-180' : ''}`} />
              </button>
              {expandedDept === dep.id && (
                <div className={`flex flex-col gap-3 mt-4 mb-2 ${isRTL ? 'pr-4 border-r-2' : 'pl-4 border-l-2'} border-primary/30`}>
                  {dep.categories.map((cat) => (
                    <Link
                      key={cat.slug}
                      href={`/drops?category=${cat.slug}`}
                      onClick={closeMobile}
                      className="font-sans text-sm tracking-wide text-muted-foreground hover:text-primary transition-colors"
                    >
                      {t(cat.arKey)}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>

        <div className="px-6 pb-10 pt-6 flex gap-8 border-t border-border shrink-0">
          <Link href="/wishlist" onClick={closeMobile} className="font-sans text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground">{t('wishlist')}</Link>
          <Link href="/cart" onClick={closeMobile} className="font-sans text-xs uppercase tracking-widest text-muted-foreground hover:text-foreground">{t('cart')}</Link>
        </div>
      </aside>
    </>
  );
}
