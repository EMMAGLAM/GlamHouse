import { Router } from "express";
import { db } from "@workspace/db";
import { dropsTable, categoriesTable } from "@workspace/db";
import { eq, sql, inArray } from "drizzle-orm";

const router = Router();

function formatDrop(drop: typeof dropsTable.$inferSelect) {
  return {
    id: drop.id,
    name: drop.name,
    description: drop.description,
    price: parseFloat(drop.price),
    originalPrice: drop.originalPrice ? parseFloat(drop.originalPrice) : null,
    imageUrl: drop.imageUrl,
    imageUrls: drop.imageUrls ?? [],
    category: drop.category,
    brand: drop.brand,
    sizes: drop.sizes ?? [],
    colors: drop.colors ?? [],
    stock: drop.stock,
    status: drop.status,
    featured: drop.featured,
    dropDate: drop.dropDate ? drop.dropDate.toISOString() : null,
    endDate: drop.endDate ? drop.endDate.toISOString() : null,
    tags: drop.tags ?? [],
    shopifyProductId: drop.shopifyProductId ?? null,
    shopifyVariantId: drop.shopifyVariantId ?? null,
  };
}

router.get("/drops", async (req, res) => {
  const { category, status, featured } = req.query;
  let drops = await db.select().from(dropsTable);

  if (category) {
    drops = drops.filter((d) => d.category === category);
  }
  if (status) {
    drops = drops.filter((d) => d.status === status);
  }
  if (featured !== undefined) {
    const isFeatured = featured === "true";
    drops = drops.filter((d) => d.featured === isFeatured);
  }

  res.json(drops.map(formatDrop));
});

router.get("/drops/featured", async (req, res) => {
  const drops = await db.select().from(dropsTable).where(eq(dropsTable.featured, true));
  res.json(drops.map(formatDrop));
});

router.get("/drops/stats", async (req, res) => {
  const allDrops = await db.select().from(dropsTable);
  const totalDrops = allDrops.length;
  const liveDrops = allDrops.filter((d) => d.status === "live").length;
  const upcomingDrops = allDrops.filter((d) => d.status === "upcoming").length;
  const brands = new Set(allDrops.map((d) => d.brand));
  const totalBrands = brands.size;

  res.json({ totalDrops, liveDrops, upcomingDrops, totalBrands });
});

router.get("/drops/:id", async (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    return res.status(400).json({ error: "Invalid id" });
  }
  const [drop] = await db.select().from(dropsTable).where(eq(dropsTable.id, id));
  if (!drop) {
    return res.status(404).json({ error: "Drop not found" });
  }
  return res.json(formatDrop(drop));
});

router.get("/categories", async (req, res) => {
  const categories = await db.select().from(categoriesTable);
  const allDrops = await db.select().from(dropsTable);

  const result = categories.map((cat) => ({
    id: cat.id,
    name: cat.name,
    slug: cat.slug,
    dropCount: allDrops.filter((d) => d.category === cat.slug).length,
  }));

  res.json(result);
});

export default router;
