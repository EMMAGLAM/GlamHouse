import { useEffect, useRef, useState } from 'react';
import { Music, VolumeX } from 'lucide-react';
import { useLang } from '@/lib/i18n';

const BASE = import.meta.env.BASE_URL.replace(/\/$/, '');
const STORAGE_KEY = 'emma-glam-music';

export function MusicToggle() {
  const { t } = useLang();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    const audio = new Audio(`${BASE}/audio/ambient.mp3`);
    audio.loop = true;
    audio.volume = 0.35;
    audioRef.current = audio;

    let saved: string | null = null;
    try {
      saved = localStorage.getItem(STORAGE_KEY);
    } catch {
      /* ignore */
    }
    if (saved === 'on') {
      audio
        .play()
        .then(() => setPlaying(true))
        .catch(() => setPlaying(false));
    }

    return () => {
      audio.pause();
      audio.src = '';
      audioRef.current = null;
    };
  }, []);

  const toggle = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
      setPlaying(false);
      try {
        localStorage.setItem(STORAGE_KEY, 'off');
      } catch {
        /* ignore */
      }
    } else {
      try {
        await audio.play();
        setPlaying(true);
        localStorage.setItem(STORAGE_KEY, 'on');
      } catch {
        setPlaying(false);
      }
    }
  };

  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={playing}
      aria-label={playing ? t('musicOff') : t('musicOn')}
      title={playing ? t('musicOff') : t('musicOn')}
      className="fixed bottom-5 end-5 z-40 w-12 h-12 rounded-full bg-foreground/90 text-background backdrop-blur-sm shadow-lg flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
    >
      {playing ? <Music className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
    </button>
  );
}
