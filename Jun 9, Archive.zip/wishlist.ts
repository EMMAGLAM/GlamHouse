import { Router } from "express";
import { db } from "@workspace/db";
import { wishlistItemsTable, dropsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

const SESSION_ID = "guest-session";

function formatDrop(drop: typeof dropsTable.$inferSelect) {
  return {
    id: drop.id,
    name: drop.name,
    description: drop.description,
    price: parseFloat(drop.price),
    originalPrice: drop.originalPrice ? parseFloat(drop.originalPrice) : null,
    imageUrl: drop.imageUrl,
    imageUrls: drop.imageUrls ?? [],
    category: drop.category,
    brand: drop.brand,
    sizes: drop.sizes ?? [],
    colors: drop.colors ?? [],
    stock: drop.stock,
    status: drop.status,
    featured: drop.featured,
    dropDate: drop.dropDate ? drop.dropDate.toISOString() : null,
    endDate: drop.endDate ? drop.endDate.toISOString() : null,
    tags: drop.tags ?? [],
  };
}

router.get("/wishlist", async (req, res) => {
  const items = await db
    .select()
    .from(wishlistItemsTable)
    .where(eq(wishlistItemsTable.sessionId, SESSION_ID));

  const dropIds = items.map((i) => i.dropId);
  let drops: (typeof dropsTable.$inferSelect)[] = [];
  if (dropIds.length > 0) {
    const allDrops = await db.select().from(dropsTable);
    drops = allDrops.filter((d) => dropIds.includes(d.id));
  }

  const dropMap = new Map(drops.map((d) => [d.id, d]));
  const result = items.map((item) => ({
    id: item.id,
    dropId: item.dropId,
    drop: formatDrop(dropMap.get(item.dropId)!),
  }));

  res.json(result);
});

router.post("/wishlist/:dropId", async (req, res) => {
  const dropId = parseInt(req.params.dropId);
  if (isNaN(dropId)) return res.status(400).json({ error: "Invalid dropId" });

  const [drop] = await db.select().from(dropsTable).where(eq(dropsTable.id, dropId));
  if (!drop) return res.status(404).json({ error: "Drop not found" });

  const [existing] = await db
    .select()
    .from(wishlistItemsTable)
    .where(and(eq(wishlistItemsTable.sessionId, SESSION_ID), eq(wishlistItemsTable.dropId, dropId)));

  if (existing) {
    return res.status(201).json({ id: existing.id, dropId: existing.dropId, drop: formatDrop(drop) });
  }

  const [item] = await db
    .insert(wishlistItemsTable)
    .values({ sessionId: SESSION_ID, dropId })
    .returning();

  return res.status(201).json({ id: item.id, dropId: item.dropId, drop: formatDrop(drop) });
});

router.delete("/wishlist/:dropId", async (req, res) => {
  const dropId = parseInt(req.params.dropId);
  if (isNaN(dropId)) return res.status(400).json({ error: "Invalid dropId" });

  await db
    .delete(wishlistItemsTable)
    .where(and(eq(wishlistItemsTable.sessionId, SESSION_ID), eq(wishlistItemsTable.dropId, dropId)));

  return res.status(204).send();
});

export default router;
