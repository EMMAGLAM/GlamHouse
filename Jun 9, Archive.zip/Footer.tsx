import React from 'react';
import { Link } from 'wouter';
import { useLang } from '@/lib/i18n';
import { Logo } from './Logo';

export function Footer() {
  const { t } = useLang();

  return (
    <footer className="bg-secondary/40 border-t border-border mt-24">
      <div className="container mx-auto px-6 py-16 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">

          <div className="col-span-1 md:col-span-2">
            <Logo size="text-3xl" className="mb-5" />
            <p className="text-muted-foreground text-sm max-w-sm leading-relaxed">
              {t('footerDesc')}
            </p>
          </div>

          <div>
            <h3 className="font-sans uppercase text-[10px] tracking-[0.2em] text-foreground font-semibold mb-5">{t('sections')}</h3>
            <ul className="space-y-3">
              <li><Link href="/drops" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('all')}</Link></li>
              <li><Link href="/drops?category=evening-dresses" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('eveningDresses')}</Link></li>
              <li><Link href="/drops?category=cocktail-dresses" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('cocktailDresses')}</Link></li>
              <li><Link href="/drops?category=casual-dresses" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('casualDresses')}</Link></li>
              <li><Link href="/drops?category=beach" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('beachPicks')}</Link></li>
              <li><Link href="/drops?category=tops" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('tops')}</Link></li>
              <li><Link href="/drops?category=suits" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('suits')}</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-sans uppercase text-[10px] tracking-[0.2em] text-foreground font-semibold mb-5">{t('account')}</h3>
            <ul className="space-y-3">
              <li><Link href="/wishlist" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('wishlist')}</Link></li>
              <li><Link href="/cart" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('cart')}</Link></li>
              <li><a href="#" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('login')}</a></li>
              <li><Link href="/admin" className="text-sm text-muted-foreground hover:text-primary transition-colors">{t('adminPanel')}</Link></li>
            </ul>
          </div>

        </div>

        <div className="mt-16 pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">&copy; {new Date().getFullYear()} EMMA GLAM. {t('rights')}.</p>
          <div className="flex gap-6">
            <a href="#" className="text-xs text-muted-foreground hover:text-primary transition-colors">{t('privacy')}</a>
            <a href="#" className="text-xs text-muted-foreground hover:text-primary transition-colors">{t('terms')}</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
