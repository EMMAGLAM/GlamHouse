import React from 'react';
import { useGetWishlist, useRemoveFromWishlist, getGetWishlistQueryKey } from '@workspace/api-client-react';
import { Layout } from '@/components/layout/Layout';
import { DropCard } from '@/components/DropCard';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Heart, Trash2 } from 'lucide-react';
import { Link } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { useLang } from '@/lib/i18n';

export default function Wishlist() {
  const { t } = useLang();
  const { data: wishlist, isLoading } = useGetWishlist();
  const removeFromWishlist = useRemoveFromWishlist();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const handleRemove = (dropId: number) => {
    removeFromWishlist.mutate(
      { dropId },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetWishlistQueryKey() });
          toast({ title: t('removedFromWishlist') });
        }
      }
    );
  };

  return (
    <Layout>
      <div className="bg-card border-b border-border py-12 md:py-20">
        <div className="container mx-auto px-4 text-center">
          <Heart className="w-8 h-8 text-primary mx-auto mb-6" />
          <h1 className="font-serif text-4xl md:text-5xl text-foreground font-light mb-4">{t('yourWishlist')}</h1>
          <p className="text-muted-foreground max-w-xl mx-auto text-sm uppercase tracking-widest">
            {wishlist?.length || 0} {t('allPieces').toLowerCase()}
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 md:py-24">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex flex-col gap-4">
                <Skeleton className="w-full aspect-[3/4] bg-muted/50 rounded-2xl" />
                <Skeleton className="h-6 w-3/4 bg-muted/50" />
                <Skeleton className="h-4 w-1/2 bg-muted/50" />
              </div>
            ))}
          </div>
        ) : wishlist && wishlist.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {wishlist.map((item) => (
              <div key={item.id} className="relative group">
                <DropCard drop={item.drop} />
                <Button
                  variant="destructive"
                  size="icon"
                  className="absolute -top-3 -right-3 z-20 rounded-full w-10 h-10 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => handleRemove(item.dropId)}
                  data-testid={`remove-wishlist-${item.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-20 text-center max-w-lg mx-auto">
            <div className="w-24 h-24 rounded-full bg-card border border-border flex items-center justify-center mb-8">
              <Heart className="w-8 h-8 text-muted-foreground" />
            </div>
            <h2 className="font-serif text-3xl text-foreground mb-4">{t('wishlistEmpty')}</h2>
            <p className="text-muted-foreground mb-10 leading-relaxed">
              {t('wishlistEmptyDesc')}
            </p>
            <Link href="/drops">
              <Button size="lg" className="rounded-none bg-primary text-primary-foreground uppercase tracking-widest text-xs h-14 px-10">
                {t('shopNow')}
              </Button>
            </Link>
          </div>
        )}
      </div>
    </Layout>
  );
}
