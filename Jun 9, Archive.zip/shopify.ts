import { Router } from "express";
import { db } from "@workspace/db";
import { dropsTable } from "@workspace/db";
import { isNull, notInArray, or } from "drizzle-orm";
import { shopifyStorefrontRequest, getShopifyStorefrontConfig } from "../shopifyStorefrontClient.js";

const router = Router();

const ADMIN_SECRET = process.env.ADMIN_SECRET;
if (!ADMIN_SECRET) {
  throw new Error("ADMIN_SECRET is required to guard admin-only Shopify routes");
}
function requireAdmin(req: any, res: any, next: any) {
  const token = req.headers["x-admin-token"];
  if (token !== ADMIN_SECRET) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

// GET /api/shopify/status — check if Shopify is connected
router.get("/shopify/status", async (req, res) => {
  try {
    const config = await getShopifyStorefrontConfig();
    res.json({ connected: true, shopDomain: config.shopDomain });
  } catch (e: any) {
    res.json({ connected: false, error: e.message });
  }
});

// POST /api/shopify/checkout — create a Shopify cart and return checkout URL
// Body: { items: [{ variantId, quantity }] }
const CART_CREATE = `#graphql
  mutation CartCreate($lines: [CartLineInput!]!) {
    cartCreate(input: { lines: $lines }) {
      cart {
        id
        checkoutUrl
        cost { totalAmount { amount currencyCode } }
      }
      userErrors { field message }
    }
  }
`;

router.post("/shopify/checkout", async (req, res) => {
  try {
    const { items } = req.body as { items: Array<{ variantId: string; quantity: number }> };
    if (!items?.length) return res.status(400).json({ error: "items required" });
    if (items.some((i) => !i.variantId)) {
      return res.status(400).json({ error: "Some items are not yet synced with Shopify" });
    }

    const lines = items.map((item) => ({
      merchandiseId: item.variantId,
      quantity: item.quantity,
    }));

    const data = await shopifyStorefrontRequest<{
      cartCreate: {
        cart: { id: string; checkoutUrl: string; cost: { totalAmount: { amount: string; currencyCode: string } } } | null;
        userErrors: Array<{ field: string; message: string }>;
      };
    }>(CART_CREATE, { lines });

    const err = data.cartCreate.userErrors[0];
    if (err) return res.status(400).json({ error: err.message });
    if (!data.cartCreate.cart?.checkoutUrl) return res.status(500).json({ error: "No checkout URL" });

    // Use dev-store preview param during development so checkout works before store goes live
    const checkoutUrl = new URL(data.cartCreate.cart.checkoutUrl);
    if (process.env.NODE_ENV !== "production") {
      checkoutUrl.searchParams.set("channel", "online_store");
    }

    return res.json({
      checkoutUrl: checkoutUrl.toString(),
      cartId: data.cartCreate.cart.id,
    });
  } catch (e: any) {
    req.log?.error(e, "Shopify checkout error");
    return res.status(500).json({ error: e.message });
  }
});

// GET /api/shopify/products — fetch live products from Shopify (optional, for future use)
const PRODUCTS_QUERY = `#graphql
  query Products($first: Int!) {
    products(first: $first) {
      nodes {
        id title handle
        featuredImage { url altText }
        priceRange { minVariantPrice { amount currencyCode } }
        variants(first: 10) { nodes { id title availableForSale } }
      }
    }
  }
`;

router.get("/shopify/products", async (req, res) => {
  try {
    const first = Math.min(parseInt(req.query.first as string) || 12, 50);
    const data = await shopifyStorefrontRequest<{ products: { nodes: unknown[] } }>(
      PRODUCTS_QUERY,
      { first },
    );
    res.json(data.products.nodes);
  } catch (e: any) {
    req.log?.error(e, "Shopify products error");
    res.status(500).json({ error: e.message });
  }
});

// POST /api/shopify/sync — mirror Shopify products into the local drops cache.
// Shopify is the system of record; the drops table is a synced read cache that
// also carries the variant id used at checkout. Removes any local rows that are
// not backed by a current Shopify product (including legacy/demo rows).
function slugify(s: string): string {
  return s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

const SYNC_QUERY = `#graphql
  query SyncProducts($first: Int!, $after: String) {
    products(first: $first, after: $after) {
      nodes {
        id
        title
        description
        vendor
        productType
        tags
        totalInventory
        featuredImage { url }
        images(first: 6) { nodes { url } }
        variants(first: 1) {
          nodes {
            id
            availableForSale
            quantityAvailable
            price { amount }
            compareAtPrice { amount }
          }
        }
      }
      pageInfo { hasNextPage endCursor }
    }
  }
`;

type SyncProduct = {
  id: string;
  title: string;
  description: string;
  vendor: string;
  productType: string;
  tags: string[];
  totalInventory: number | null;
  featuredImage: { url: string } | null;
  images: { nodes: Array<{ url: string }> };
  variants: {
    nodes: Array<{
      id: string;
      availableForSale: boolean;
      quantityAvailable: number | null;
      price: { amount: string };
      compareAtPrice: { amount: string } | null;
    }>;
  };
};

router.post("/shopify/sync", requireAdmin, async (req, res) => {
  try {
    // Page through the entire catalog before computing the stale-row delete set,
    // otherwise valid mirrored rows beyond the first page would be wrongly removed.
    const allNodes: SyncProduct[] = [];
    let after: string | null = null;
    do {
      const data: { products: { nodes: SyncProduct[]; pageInfo: { hasNextPage: boolean; endCursor: string | null } } } =
        await shopifyStorefrontRequest(SYNC_QUERY, { first: 100, after });
      allNodes.push(...data.products.nodes);
      after = data.products.pageInfo.hasNextPage ? data.products.pageInfo.endCursor : null;
    } while (after);

    const products = allNodes.filter((p) => p.variants.nodes.length > 0);

    for (const p of products) {
      const variant = p.variants.nodes[0];
      const images = p.images?.nodes?.map((n) => n.url) ?? [];
      const imageUrl = p.featuredImage?.url || images[0] || "/images/drop-dress.png";
      // Supplier-fulfilled store: availability comes from Shopify's availableForSale,
      // not a tracked quantity. Inventory is untracked (inventoryPolicy CONTINUE),
      // so totalInventory is meaningless here — keep a fixed positive stock whenever
      // the item is sellable so storefront purchase controls stay enabled.
      const available = variant.availableForSale;
      const stock = available ? 99 : 0;
      const category = (p.productType && slugify(p.productType)) || "sets";
      // Only treat compareAtPrice as an "original" (strikethrough) price when it is
      // genuinely higher than the selling price. Imported products often carry a
      // compareAtPrice equal to supplier cost (lower than retail), which would
      // otherwise render a misleading strikethrough that looks like a price increase.
      const compareAt = variant.compareAtPrice?.amount ?? null;
      const originalPrice =
        compareAt != null && Number(compareAt) > Number(variant.price.amount) ? compareAt : null;

      const values = {
        name: p.title,
        description: p.description || p.title,
        price: variant.price.amount,
        originalPrice,
        imageUrl,
        imageUrls: images,
        category,
        brand: p.vendor || "EMMA GLAM",
        sizes: [] as string[],
        colors: [] as string[],
        stock,
        status: available ? "live" : "sold_out",
        featured: p.tags?.includes("featured") ?? false,
        tags: p.tags ?? [],
        shopifyProductId: p.id,
        shopifyVariantId: variant.id,
      };

      await db
        .insert(dropsTable)
        .values(values)
        .onConflictDoUpdate({ target: dropsTable.shopifyProductId, set: values });
    }

    const ids = products.map((p) => p.id);
    if (ids.length > 0) {
      await db
        .delete(dropsTable)
        .where(or(isNull(dropsTable.shopifyProductId), notInArray(dropsTable.shopifyProductId, ids)));
    } else {
      await db.delete(dropsTable).where(isNull(dropsTable.shopifyProductId));
    }

    res.json({ synced: products.length });
  } catch (e: any) {
    req.log?.error(e, "Shopify sync error");
    res.status(500).json({ error: e.message });
  }
});

export default router;
